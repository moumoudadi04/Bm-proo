package com.example

import com.example.data.model.CustomerDebtEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun customerDebtEntity_overdueCalculation_worksCorrectly() {
        // Debt with due date in the past
        val pastDueDebt = CustomerDebtEntity(
            id = 1,
            customerName = "متجر الأمل",
            customerPhone = "+966500000000",
            totalDebt = 1500.0,
            paidAmount = 500.0,
            remainingDebt = 1000.0,
            dueDate = System.currentTimeMillis() - 86400000L, // 1 day ago
            customerLocation = "24.7136,46.6753",
            storeAddress = "الرياض - شارع الملك فهد",
            isSettled = false
        )
        assertTrue("Debt with past due date and remaining balance must be overdue", pastDueDebt.isOverdue)

        // Settled debt
        val settledDebt = pastDueDebt.copy(
            paidAmount = 1500.0,
            remainingDebt = 0.0,
            isSettled = true
        )
        assertFalse("Settled debt should not be marked as overdue", settledDebt.isOverdue)

        // Future debt
        val futureDebt = pastDueDebt.copy(
            dueDate = System.currentTimeMillis() + 86400000L // tomorrow
        )
        assertFalse("Future debt should not be overdue", futureDebt.isOverdue)
    }
}
