package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.util.SecurityManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun read_string_from_context() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("ProSto", appName)
    }

    @Test
    fun securityManager_activationAndKeyVerification_worksProperly() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val securityManager = SecurityManager(context)

        // Initial state before activation
        assertFalse("App should not be activated initially", securityManager.isActivated())
        assertTrue("Device ID must not be blank", securityManager.getDeviceId().isNotBlank())

        // Wrong password should fail
        val wrongActivation = securityManager.verifyAndActivate("WRONG_KEY_123")
        assertFalse("Wrong key must be rejected", wrongActivation)
        assertFalse("App should remain unactivated", securityManager.isActivated())

        // Correct default master key should succeed
        val correctActivation = securityManager.verifyAndActivate("BM2026")
        assertTrue("Correct master key must be accepted", correctActivation)
        assertTrue("App should now be activated", securityManager.isActivated())

        // Change master key
        val changeSuccess = securityManager.changeMasterKey("BM2026", "NEW_BM_PASS_99")
        assertTrue("Changing master key with correct old key must succeed", changeSuccess)
        assertEquals("NEW_BM_PASS_99", securityManager.getMasterKey())

        // Reset activation (phone switch simulation)
        securityManager.resetActivation()
        assertFalse("App should require activation again after reset", securityManager.isActivated())
    }
}
