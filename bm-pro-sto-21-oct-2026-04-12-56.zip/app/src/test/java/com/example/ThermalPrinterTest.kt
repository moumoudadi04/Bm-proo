package com.example

import com.example.data.model.InvoiceEntity
import com.example.data.model.InvoiceItemEntity
import com.example.data.model.InvoiceType
import com.example.data.model.PaymentMethod
import com.example.printer.PrinterConfig
import com.example.printer.PrinterPaperWidth
import com.example.printer.ThermalPrinterManager
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ThermalPrinterTest {

    @Test
    fun testReceiptGeneration() {
        val config = PrinterConfig(
            storeName = "BM Logistics & Warehouse",
            paperWidth = PrinterPaperWidth.WIDTH_58MM
        )

        val invoice = InvoiceEntity(
            id = 1,
            invoiceNumber = "INV-9999",
            type = InvoiceType.SALE,
            partyName = "Test Customer",
            subtotal = 100.0,
            discount = 10.0,
            taxRate = 0.15,
            totalAmount = 103.5,
            paymentMethod = PaymentMethod.CASH
        )

        val items = listOf(
            InvoiceItemEntity(
                id = 1,
                invoiceId = 1,
                productId = 10,
                productName = "Barcode Scanner 2D",
                barcode = "123456789",
                quantity = 1.0,
                unitPrice = 100.0,
                costPrice = 60.0,
                total = 100.0
            )
        )

        val textReceipt = ThermalPrinterManager.buildInvoiceTextReceipt(invoice, items, config)
        assertNotNull(textReceipt)
        assertTrue(textReceipt.contains("INV-9999"))
        assertTrue(textReceipt.contains("Barcode Scanner 2D"))

        val escPos = ThermalPrinterManager.buildEscPosBytes(invoice, items, config)
        assertNotNull(escPos)
        assertTrue(escPos.isNotEmpty())
    }
}
