package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.CustomerDebtEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CustomerDebtDao {
    @Query("SELECT * FROM customer_debts ORDER BY dueDate ASC")
    fun getAllDebts(): Flow<List<CustomerDebtEntity>>

    @Query("SELECT * FROM customer_debts WHERE isSettled = 0 AND dueDate < :currentTimestamp ORDER BY dueDate ASC")
    fun getOverdueDebts(currentTimestamp: Long): Flow<List<CustomerDebtEntity>>

    @Query("SELECT * FROM customer_debts WHERE isSettled = 0 ORDER BY dueDate ASC")
    fun getActiveDebts(): Flow<List<CustomerDebtEntity>>

    @Query("SELECT * FROM customer_debts WHERE id = :id LIMIT 1")
    suspend fun getDebtById(id: Long): CustomerDebtEntity?

    @Query("SELECT SUM(remainingDebt) FROM customer_debts WHERE isSettled = 0")
    fun getTotalRemainingDebt(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: CustomerDebtEntity): Long

    @Update
    suspend fun updateDebt(debt: CustomerDebtEntity)

    @Query("DELETE FROM customer_debts WHERE id = :id")
    suspend fun deleteDebt(id: Long)
}
