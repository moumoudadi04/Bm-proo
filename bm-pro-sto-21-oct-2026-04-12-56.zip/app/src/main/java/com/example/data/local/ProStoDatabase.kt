package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.InvoiceEntity
import com.example.data.model.InvoiceItemEntity
import com.example.data.model.InvoiceType
import com.example.data.model.MovementType
import com.example.data.model.PaymentMethod
import com.example.data.model.ProductEntity
import com.example.data.model.StockMovementEntity
import com.example.data.model.StocktakeItemEntity
import com.example.data.model.StocktakeSessionEntity
import com.example.data.model.StocktakeStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class Converters {
    @TypeConverter
    fun fromMovementType(value: MovementType): String = value.name

    @TypeConverter
    fun toMovementType(value: String): MovementType = try {
        MovementType.valueOf(value)
    } catch (_: Exception) {
        MovementType.IN
    }

    @TypeConverter
    fun fromInvoiceType(value: InvoiceType): String = value.name

    @TypeConverter
    fun toInvoiceType(value: String): InvoiceType = try {
        InvoiceType.valueOf(value)
    } catch (_: Exception) {
        InvoiceType.SALE
    }

    @TypeConverter
    fun fromPaymentMethod(value: PaymentMethod): String = value.name

    @TypeConverter
    fun toPaymentMethod(value: String): PaymentMethod = try {
        PaymentMethod.valueOf(value)
    } catch (_: Exception) {
        PaymentMethod.CASH
    }

    @TypeConverter
    fun fromStocktakeStatus(value: StocktakeStatus): String = value.name

    @TypeConverter
    fun toStocktakeStatus(value: String): StocktakeStatus = try {
        StocktakeStatus.valueOf(value)
    } catch (_: Exception) {
        StocktakeStatus.IN_PROGRESS
    }
}

@Database(
    entities = [
        ProductEntity::class,
        StockMovementEntity::class,
        InvoiceEntity::class,
        InvoiceItemEntity::class,
        StocktakeSessionEntity::class,
        StocktakeItemEntity::class,
        com.example.data.model.CustomerDebtEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class ProStoDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun movementDao(): MovementDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun stocktakeDao(): StocktakeDao
    abstract fun debtDao(): CustomerDebtDao

    companion object {
        @Volatile
        private var INSTANCE: ProStoDatabase? = null

        fun getDatabase(context: Context): ProStoDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ProStoDatabase::class.java,
                    "prosto_inventory.db"
                ).addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        // Pre-populate with realistic initial inventory
                        CoroutineScope(Dispatchers.IO).launch {
                            val dbInstance = getDatabase(context)
                            val productDao = dbInstance.productDao()
                            val movementDao = dbInstance.movementDao()
                            val invoiceDao = dbInstance.invoiceDao()
                            val debtDao = dbInstance.debtDao()
                            seedInitialData(productDao, movementDao, invoiceDao, debtDao)
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }

        private suspend fun seedInitialData(
            productDao: ProductDao,
            movementDao: MovementDao,
            invoiceDao: InvoiceDao,
            debtDao: CustomerDebtDao
        ) {
            val initialProducts = listOf(
                ProductEntity(
                    barcode = "628100120001",
                    nameAr = "طابعة فواتير حرارية 58mm بلوتوث",
                    nameEn = "58mm Bluetooth Thermal Receipt Printer",
                    category = "أجهزة ومعدات / Equipment",
                    unit = "قطعة / Pcs",
                    costPrice = 180.0,
                    sellPrice = 260.0,
                    currentStock = 14.0,
                    minAlertStock = 5.0,
                    location = "A-01"
                ),
                ProductEntity(
                    barcode = "628100120002",
                    nameAr = "رول ورق حراري 80mm عالي الجودة",
                    nameEn = "80mm Thermal Paper Rolls (Box 50)",
                    category = "مستهلكات / Supplies",
                    unit = "كرتونة / Box",
                    costPrice = 45.0,
                    sellPrice = 75.0,
                    currentStock = 3.0, // Low stock trigger!
                    minAlertStock = 10.0,
                    location = "B-03"
                ),
                ProductEntity(
                    barcode = "628100120003",
                    nameAr = "قارئ باركود لاسلكي 2D",
                    nameEn = "Wireless 2D Barcode Scanner",
                    category = "أجهزة ومعدات / Equipment",
                    unit = "قطعة / Pcs",
                    costPrice = 95.0,
                    sellPrice = 145.0,
                    currentStock = 8.0,
                    minAlertStock = 4.0,
                    location = "A-02"
                ),
                ProductEntity(
                    barcode = "628100120004",
                    nameAr = "درج كاشير نقود معدني أوتوماتيكي",
                    nameEn = "Automatic Heavy Duty Cash Drawer",
                    category = "أجهزة ومعدات / Equipment",
                    unit = "قطعة / Pcs",
                    costPrice = 110.0,
                    sellPrice = 170.0,
                    currentStock = 0.0, // Out of stock trigger!
                    minAlertStock = 3.0,
                    location = "C-01"
                ),
                ProductEntity(
                    barcode = "628100120005",
                    nameAr = "ورق حراري 57x40mm لماكينات مدى",
                    nameEn = "57x40mm POS Thermal Rolls",
                    category = "مستهلكات / Supplies",
                    unit = "باكيت / Pack",
                    costPrice = 18.0,
                    sellPrice = 30.0,
                    currentStock = 45.0,
                    minAlertStock = 15.0,
                    location = "B-04"
                ),
                ProductEntity(
                    barcode = "628100120006",
                    nameAr = "شاشة نقاط بيع لمس 15.6 بوصة",
                    nameEn = "15.6 Inch Touch POS Terminal",
                    category = "أنظمة نقاط البيع / POS Systems",
                    unit = "جهاز / Device",
                    costPrice = 900.0,
                    sellPrice = 1350.0,
                    currentStock = 6.0,
                    minAlertStock = 2.0,
                    location = "A-05"
                ),
                ProductEntity(
                    barcode = "628100120007",
                    nameAr = "حامل تابلت وستاند كاشير دوار",
                    nameEn = "Rotary Tablet POS Stand",
                    category = "إكسسوارات / Accessories",
                    unit = "قطعة / Pcs",
                    costPrice = 50.0,
                    sellPrice = 85.0,
                    currentStock = 2.0, // Low stock trigger!
                    minAlertStock = 5.0,
                    location = "C-02"
                )
            )

            productDao.insertAll(initialProducts)

            // Seed initial stock movement log
            initialProducts.forEach { product ->
                movementDao.insertMovement(
                    StockMovementEntity(
                        productId = 0,
                        productName = product.nameAr,
                        type = MovementType.IN,
                        quantity = product.currentStock,
                        previousStock = 0.0,
                        newStock = product.currentStock,
                        unitPrice = product.costPrice,
                        referenceInvoice = "INIT-STOCK",
                        notes = "رصيد افتتاحي للمخزن / Initial Stock"
                    )
                )
            }

            // Seed a sample sales invoice
            val sampleInvoiceId = invoiceDao.insertInvoice(
                InvoiceEntity(
                    invoiceNumber = "INV-1001",
                    type = InvoiceType.SALE,
                    partyName = "شركة النور للمقاولات / Al Noor Co",
                    partyPhone = "0501234567",
                    subtotal = 380.0,
                    discount = 20.0,
                    taxRate = 0.15,
                    totalAmount = 414.0,
                    paymentMethod = PaymentMethod.CASH,
                    notes = "تمت الطباعة على طابعة 80mm حرارية"
                )
            )

            invoiceDao.insertInvoiceItems(
                listOf(
                    InvoiceItemEntity(
                        invoiceId = sampleInvoiceId,
                        productId = 1,
                        productName = "طابعة فواتير حرارية 58mm بلوتوث",
                        barcode = "628100120001",
                        quantity = 1.0,
                        unitPrice = 260.0,
                        costPrice = 180.0,
                        total = 260.0
                    ),
                    InvoiceItemEntity(
                        invoiceId = sampleInvoiceId,
                        productId = 7,
                        productName = "حامل تابلت وستاند كاشير دوار",
                        barcode = "628100120007",
                        quantity = 1.0,
                        unitPrice = 85.0,
                        costPrice = 50.0,
                        total = 85.0
                    ),
                    InvoiceItemEntity(
                        invoiceId = sampleInvoiceId,
                        productId = 5,
                        productName = "ورق حراري 57x40mm لماكينات مدى",
                        barcode = "628100120005",
                        quantity = 1.0,
                        unitPrice = 30.0,
                        costPrice = 18.0,
                        total = 30.0
                    )
                )
            )

            // Seed initial debts (including overdue alerts!)
            val now = System.currentTimeMillis()
            val dayMs = 86400000L

            debtDao.insertDebt(
                com.example.data.model.CustomerDebtEntity(
                    customerName = "مؤسسة الوفاء للتجارة / Al Wafa Co",
                    customerPhone = "0559876543",
                    totalDebt = 1450.0,
                    paidAmount = 0.0,
                    remainingDebt = 1450.0,
                    dueDate = now - (5 * dayMs), // Overdue by 5 days!
                    invoiceNumber = "INV-0982",
                    notes = "فاتورة مشتريات آجل - شاحنة توزيع رقم 2"
                )
            )

            debtDao.insertDebt(
                com.example.data.model.CustomerDebtEntity(
                    customerName = "سوبرماركت المدينة / City Mart",
                    customerPhone = "0561122334",
                    totalDebt = 2200.0,
                    paidAmount = 700.0,
                    remainingDebt = 1500.0,
                    dueDate = now + (3 * dayMs), // Due in 3 days
                    invoiceNumber = "INV-0995",
                    notes = "دفعة أولى مسددة 700 ر.س نقداً"
                )
            )
        }
    }
}
