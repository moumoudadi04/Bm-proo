package com.example.data.repository

import com.example.data.local.InvoiceDao
import com.example.data.local.MovementDao
import com.example.data.local.ProductDao
import com.example.data.local.StocktakeDao
import com.example.data.model.InvoiceEntity
import com.example.data.model.InvoiceItemEntity
import com.example.data.model.InvoiceType
import com.example.data.model.MovementType
import com.example.data.model.PaymentMethod
import com.example.data.model.ProductEntity
import com.example.data.model.StockMovementEntity
import com.example.data.model.StocktakeItemEntity
import com.example.data.model.StocktakeSessionEntity
import com.example.data.model.StocktakeStatus
import com.example.printer.PrinterConfig
import com.example.util.AppLanguage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ShiftState(
    val isActive: Boolean = true,
    val cashierName: String = "المدير العام / Admin",
    val startedAt: Long = System.currentTimeMillis(),
    val openingCash: Double = 500.0
)

class InventoryRepository(
    private val productDao: ProductDao,
    private val movementDao: MovementDao,
    private val invoiceDao: InvoiceDao,
    private val stocktakeDao: StocktakeDao,
    private val debtDao: com.example.data.local.CustomerDebtDao
) {
    // Master Startup Switch (مفتاح بدء التشغيل)
    private val _shiftState = MutableStateFlow(ShiftState())
    val shiftState: StateFlow<ShiftState> = _shiftState.asStateFlow()

    fun toggleMasterStartupKey() {
        val current = _shiftState.value
        if (current.isActive) {
            _shiftState.value = current.copy(isActive = false)
        } else {
            _shiftState.value = current.copy(isActive = true, startedAt = System.currentTimeMillis())
        }
    }

    // Language setting
    private val _currentLanguage = MutableStateFlow(AppLanguage.ARABIC)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    fun setLanguage(language: AppLanguage) {
        _currentLanguage.value = language
    }

    // Printer Config
    private val _printerConfig = MutableStateFlow(PrinterConfig())
    val printerConfig: StateFlow<PrinterConfig> = _printerConfig.asStateFlow()

    fun updatePrinterConfig(config: PrinterConfig) {
        _printerConfig.value = config
    }

    // Products
    val allProducts: Flow<List<ProductEntity>> = productDao.getAllProducts()
    val lowStockProducts: Flow<List<ProductEntity>> = productDao.getLowStockProducts()
    val totalProductCount: Flow<Int> = productDao.getProductCount()
    val totalCostValue: Flow<Double?> = productDao.getTotalCostValue()
    val totalSellValue: Flow<Double?> = productDao.getTotalSellValue()

    fun searchProducts(query: String): Flow<List<ProductEntity>> {
        return if (query.isBlank()) {
            productDao.getAllProducts()
        } else {
            productDao.searchProducts(query)
        }
    }

    suspend fun saveProduct(product: ProductEntity): Long {
        return if (product.id == 0L) {
            val id = productDao.insertProduct(product)
            movementDao.insertMovement(
                StockMovementEntity(
                    productId = id,
                    productName = product.nameAr,
                    type = MovementType.IN,
                    quantity = product.currentStock,
                    previousStock = 0.0,
                    newStock = product.currentStock,
                    unitPrice = product.costPrice,
                    notes = "صنف جديد / New Product Created"
                )
            )
            id
        } else {
            val oldProduct = productDao.getProductById(product.id)
            productDao.updateProduct(product)
            if (oldProduct != null && oldProduct.currentStock != product.currentStock) {
                val diff = product.currentStock - oldProduct.currentStock
                val type = if (diff >= 0) MovementType.IN else MovementType.OUT
                movementDao.insertMovement(
                    StockMovementEntity(
                        productId = product.id,
                        productName = product.nameAr,
                        type = type,
                        quantity = kotlin.math.abs(diff),
                        previousStock = oldProduct.currentStock,
                        newStock = product.currentStock,
                        unitPrice = product.costPrice,
                        notes = "تعديل رصيد يدوي / Manual stock update"
                    )
                )
            }
            product.id
        }
    }

    suspend fun quickRestock(productId: Long, addedQty: Double, notes: String = "توريد سريع") {
        val product = productDao.getProductById(productId) ?: return
        val newStock = product.currentStock + addedQty
        productDao.updateStock(productId, newStock)
        movementDao.insertMovement(
            StockMovementEntity(
                productId = productId,
                productName = product.nameAr,
                type = MovementType.IN,
                quantity = addedQty,
                previousStock = product.currentStock,
                newStock = newStock,
                unitPrice = product.costPrice,
                notes = notes
            )
        )
    }

    suspend fun deleteProduct(productId: Long) {
        productDao.deleteProduct(productId)
    }

    // Movements
    val recentMovements: Flow<List<StockMovementEntity>> = movementDao.getRecentMovements(50)

    // Invoices & POS
    val allInvoices: Flow<List<InvoiceEntity>> = invoiceDao.getAllInvoices()

    suspend fun createInvoice(
        type: InvoiceType = InvoiceType.SALE,
        partyName: String,
        partyPhone: String,
        discount: Double,
        taxRate: Double,
        paymentMethod: PaymentMethod,
        cartItems: List<Pair<ProductEntity, Double>>,
        customerLocation: String = "",
        storeAddress: String = "",
        notes: String = ""
    ): Pair<InvoiceEntity, List<InvoiceItemEntity>> {
        val invoiceNumber = "INV-${System.currentTimeMillis() % 1000000}"
        val subtotal = cartItems.sumOf { (product, qty) -> product.sellPrice * qty }
        val discountedSubtotal = (subtotal - discount).coerceAtLeast(0.0)
        val taxAmount = discountedSubtotal * taxRate
        val totalAmount = discountedSubtotal + taxAmount

        val invoice = InvoiceEntity(
            invoiceNumber = invoiceNumber,
            type = type,
            partyName = partyName.ifBlank { "عميل نقدي / Cash Customer" },
            partyPhone = partyPhone,
            subtotal = subtotal,
            discount = discount,
            taxRate = taxRate,
            totalAmount = totalAmount,
            paymentMethod = paymentMethod,
            customerLocation = customerLocation,
            notes = notes
        )

        val invoiceId = invoiceDao.insertInvoice(invoice)
        val savedInvoice = invoice.copy(id = invoiceId)

        val invoiceItems = cartItems.map { (product, qty) ->
            InvoiceItemEntity(
                invoiceId = invoiceId,
                productId = product.id,
                productName = product.nameAr,
                barcode = product.barcode,
                quantity = qty,
                unitPrice = product.sellPrice,
                costPrice = product.costPrice,
                total = product.sellPrice * qty
            )
        }
        invoiceDao.insertInvoiceItems(invoiceItems)

        // Deduct inventory and record stock movements
        for ((product, qty) in cartItems) {
            val updatedStock = product.currentStock - qty
            productDao.updateStock(product.id, updatedStock)
            movementDao.insertMovement(
                StockMovementEntity(
                    productId = product.id,
                    productName = product.nameAr,
                    type = MovementType.OUT,
                    quantity = qty,
                    previousStock = product.currentStock,
                    newStock = updatedStock,
                    unitPrice = product.sellPrice,
                    referenceInvoice = invoiceNumber,
                    notes = "فاتورة بيع رقم $invoiceNumber"
                )
            )
        }

        // If debt sale, automatically register in customer debts ledger
        if (paymentMethod == PaymentMethod.DEBT) {
            val dueDateMs = System.currentTimeMillis() + (14 * 86400000L) // 14 days default
            debtDao.insertDebt(
                com.example.data.model.CustomerDebtEntity(
                    customerName = invoice.partyName,
                    customerPhone = invoice.partyPhone,
                    totalDebt = invoice.totalAmount,
                    paidAmount = 0.0,
                    remainingDebt = invoice.totalAmount,
                    dueDate = dueDateMs,
                    invoiceNumber = invoiceNumber,
                    customerLocation = customerLocation,
                    storeAddress = storeAddress,
                    notes = "فاتورة بيع آجل رقم $invoiceNumber"
                )
            )
        }

        return Pair(savedInvoice, invoiceItems)
    }

    suspend fun getInvoiceItems(invoiceId: Long): List<InvoiceItemEntity> {
        return invoiceDao.getItemsForInvoice(invoiceId)
    }

    // Debts & Overdue Alerts (الديون والتنبيهات)
    val allDebts: Flow<List<com.example.data.model.CustomerDebtEntity>> = debtDao.getAllDebts()
    val overdueDebts: Flow<List<com.example.data.model.CustomerDebtEntity>> =
        debtDao.getOverdueDebts(System.currentTimeMillis())
    val totalRemainingDebt: Flow<Double?> = debtDao.getTotalRemainingDebt()

    suspend fun saveDebt(debt: com.example.data.model.CustomerDebtEntity): Long {
        return if (debt.id == 0L) {
            debtDao.insertDebt(debt)
        } else {
            debtDao.updateDebt(debt)
            debt.id
        }
    }

    suspend fun recordDebtPayment(debtId: Long, paymentAmount: Double) {
        val debt = debtDao.getDebtById(debtId) ?: return
        val newPaid = debt.paidAmount + paymentAmount
        val newRemaining = (debt.totalDebt - newPaid).coerceAtLeast(0.0)
        val isSettled = newRemaining <= 0.0
        val updated = debt.copy(
            paidAmount = newPaid,
            remainingDebt = newRemaining,
            isSettled = isSettled,
            lastPaymentDate = System.currentTimeMillis()
        )
        debtDao.updateDebt(updated)
    }

    suspend fun deleteDebt(debtId: Long) {
        debtDao.deleteDebt(debtId)
    }

    // Stocktake (الجرد الدقيق)
    val allStocktakeSessions: Flow<List<StocktakeSessionEntity>> = stocktakeDao.getAllSessions()

    fun getItemsForSession(sessionId: Long): Flow<List<StocktakeItemEntity>> =
        stocktakeDao.getItemsForSession(sessionId)

    suspend fun startNewStocktakeSession(title: String, products: List<ProductEntity>): Long {
        val sessionTitle = title.ifBlank { "جرد مخزني - " + SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date()) }
        val session = StocktakeSessionEntity(
            title = sessionTitle,
            status = StocktakeStatus.IN_PROGRESS
        )
        val sessionId = stocktakeDao.insertSession(session)

        val items = products.map { product ->
            StocktakeItemEntity(
                sessionId = sessionId,
                productId = product.id,
                productName = product.nameAr,
                barcode = product.barcode,
                expectedStock = product.currentStock,
                actualCount = product.currentStock, // Default to expected, auditor modifies
                variance = 0.0,
                costPrice = product.costPrice,
                varianceValue = 0.0
            )
        }
        stocktakeDao.insertSessionItems(items)
        return sessionId
    }

    suspend fun updateStocktakeItemCount(item: StocktakeItemEntity, newActualCount: Double) {
        val variance = newActualCount - item.expectedStock
        val varianceValue = variance * item.costPrice
        val updated = item.copy(
            actualCount = newActualCount,
            variance = variance,
            varianceValue = varianceValue
        )
        stocktakeDao.insertOrUpdateItem(updated)
    }

    suspend fun reconcileAndCloseStocktake(sessionId: Long) {
        val items = stocktakeDao.getItemsForSessionOnce(sessionId)
        var discrepancies = 0
        var totalVariance = 0.0

        for (item in items) {
            if (item.variance != 0.0) {
                discrepancies++
                totalVariance += item.varianceValue
                // Update actual product stock in inventory
                productDao.updateStock(item.productId, item.actualCount)
                // Record stock movement
                val movType = if (item.variance > 0) MovementType.IN else MovementType.AUDIT_ADJUST
                movementDao.insertMovement(
                    StockMovementEntity(
                        productId = item.productId,
                        productName = item.productName,
                        type = movType,
                        quantity = kotlin.math.abs(item.variance),
                        previousStock = item.expectedStock,
                        newStock = item.actualCount,
                        unitPrice = item.costPrice,
                        referenceInvoice = "AUDIT-$sessionId",
                        notes = "تسوية جرد دوري (فارق: ${item.variance})"
                    )
                )
            }
        }

        stocktakeDao.closeSession(
            sessionId = sessionId,
            status = StocktakeStatus.COMPLETED,
            closedAt = System.currentTimeMillis(),
            checked = items.size,
            discrepancies = discrepancies,
            varianceValue = totalVariance
        )
    }

    // Cloud Database & Sync operations
    private val _lastCloudSyncTimestamp = MutableStateFlow(System.currentTimeMillis())
    val lastCloudSyncTimestamp: StateFlow<Long> = _lastCloudSyncTimestamp.asStateFlow()

    private val _isCloudSyncing = MutableStateFlow(false)
    val isCloudSyncing: StateFlow<Boolean> = _isCloudSyncing.asStateFlow()

    suspend fun triggerCloudSync() {
        _isCloudSyncing.value = true
        kotlinx.coroutines.delay(1200) // Simulate cloud handshake
        _lastCloudSyncTimestamp.value = System.currentTimeMillis()
        _isCloudSyncing.value = false
    }

    suspend fun exportCloudBackupJson(products: List<ProductEntity>, invoices: List<InvoiceEntity>): String {
        val root = JSONObject()
        root.put("version", "1.0")
        root.put("appName", "ProSto")
        root.put("exportedAt", System.currentTimeMillis())

        val productsArray = JSONArray()
        products.forEach { p ->
            val obj = JSONObject()
            obj.put("barcode", p.barcode)
            obj.put("nameAr", p.nameAr)
            obj.put("nameEn", p.nameEn)
            obj.put("category", p.category)
            obj.put("unit", p.unit)
            obj.put("costPrice", p.costPrice)
            obj.put("sellPrice", p.sellPrice)
            obj.put("currentStock", p.currentStock)
            obj.put("minAlertStock", p.minAlertStock)
            productsArray.put(obj)
        }
        root.put("products", productsArray)

        val invoicesArray = JSONArray()
        invoices.forEach { inv ->
            val obj = JSONObject()
            obj.put("invoiceNumber", inv.invoiceNumber)
            obj.put("partyName", inv.partyName)
            obj.put("totalAmount", inv.totalAmount)
            obj.put("timestamp", inv.timestamp)
            invoicesArray.put(obj)
        }
        root.put("invoices", invoicesArray)

        return root.toString(2)
    }
}
