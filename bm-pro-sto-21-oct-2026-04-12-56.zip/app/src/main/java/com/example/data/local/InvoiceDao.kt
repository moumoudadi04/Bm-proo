package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import com.example.data.model.InvoiceEntity
import com.example.data.model.InvoiceItemEntity
import com.example.data.model.StocktakeItemEntity
import com.example.data.model.StocktakeSessionEntity
import com.example.data.model.StocktakeStatus
import kotlinx.coroutines.flow.Flow

data class InvoiceWithItems(
    val invoice: InvoiceEntity,
    val items: List<InvoiceItemEntity>
)

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices ORDER BY timestamp DESC")
    fun getAllInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE id = :id LIMIT 1")
    suspend fun getInvoiceById(id: Long): InvoiceEntity?

    @Query("SELECT * FROM invoice_items WHERE invoiceId = :invoiceId")
    suspend fun getItemsForInvoice(invoiceId: Long): List<InvoiceItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: InvoiceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoiceItems(items: List<InvoiceItemEntity>)

    @Query("SELECT COUNT(*) FROM invoices WHERE timestamp >= :sinceTimestamp")
    fun getInvoicesCountSince(sinceTimestamp: Long): Flow<Int>

    @Query("SELECT SUM(totalAmount) FROM invoices WHERE timestamp >= :sinceTimestamp")
    fun getTotalSalesSince(sinceTimestamp: Long): Flow<Double?>

    @Query("SELECT * FROM invoice_items ORDER BY id DESC LIMIT :limit")
    fun getRecentSoldItems(limit: Int = 100): Flow<List<InvoiceItemEntity>>
}

@Dao
interface StocktakeDao {
    @Query("SELECT * FROM stocktake_sessions ORDER BY startedAt DESC")
    fun getAllSessions(): Flow<List<StocktakeSessionEntity>>

    @Query("SELECT * FROM stocktake_sessions WHERE id = :id LIMIT 1")
    suspend fun getSessionById(id: Long): StocktakeSessionEntity?

    @Query("SELECT * FROM stocktake_items WHERE sessionId = :sessionId")
    fun getItemsForSession(sessionId: Long): Flow<List<StocktakeItemEntity>>

    @Query("SELECT * FROM stocktake_items WHERE sessionId = :sessionId")
    suspend fun getItemsForSessionOnce(sessionId: Long): List<StocktakeItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StocktakeSessionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSessionItems(items: List<StocktakeItemEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateItem(item: StocktakeItemEntity): Long

    @Query("UPDATE stocktake_sessions SET status = :status, closedAt = :closedAt, totalItemsChecked = :checked, discrepanciesCount = :discrepancies, totalVarianceValue = :varianceValue WHERE id = :sessionId")
    suspend fun closeSession(
        sessionId: Long,
        status: StocktakeStatus = StocktakeStatus.COMPLETED,
        closedAt: Long = System.currentTimeMillis(),
        checked: Int,
        discrepancies: Int,
        varianceValue: Double
    )
}
