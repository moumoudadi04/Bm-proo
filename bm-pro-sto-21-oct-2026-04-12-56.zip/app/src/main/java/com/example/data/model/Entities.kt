package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val barcode: String,
    val nameAr: String,
    val nameEn: String,
    val category: String,
    val unit: String = "قطعة / Pcs",
    val costPrice: Double,
    val sellPrice: Double,
    val currentStock: Double,
    val minAlertStock: Double = 5.0,
    val location: String = "A-1",
    val supplier: String = "",
    val notes: String = "",
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val isLowStock: Boolean
        get() = currentStock <= minAlertStock && currentStock > 0

    val isOutOfStock: Boolean
        get() = currentStock <= 0
}

enum class MovementType {
    IN,            // وارد / استلام
    OUT,           // صادر / بيع
    AUDIT_ADJUST,  // تسوية جرد
    DAMAGED        // تالف / منتهي
}

@Entity(tableName = "stock_movements")
data class StockMovementEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val productId: Long,
    val productName: String,
    val type: MovementType,
    val quantity: Double,
    val previousStock: Double,
    val newStock: Double,
    val unitPrice: Double,
    val referenceInvoice: String = "",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

enum class InvoiceType {
    SALE,     // مبيعات
    PURCHASE, // مشتريات
    RETURN    // مرتجع
}

enum class PaymentMethod {
    CASH,     // نقداً
    CARD,     // بطاقة / شبكة
    DEBT      // آجل
}

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val invoiceNumber: String,
    val type: InvoiceType = InvoiceType.SALE,
    val partyName: String = "عميل نقدي / Cash Customer",
    val partyPhone: String = "",
    val subtotal: Double,
    val discount: Double = 0.0,
    val taxRate: Double = 0.0,
    val totalAmount: Double,
    val paymentMethod: PaymentMethod = PaymentMethod.CASH,
    val customerLocation: String = "",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "invoice_items")
data class InvoiceItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val invoiceId: Long,
    val productId: Long,
    val productName: String,
    val barcode: String,
    val quantity: Double,
    val unitPrice: Double,
    val costPrice: Double,
    val total: Double
)

enum class StocktakeStatus {
    IN_PROGRESS,
    COMPLETED
}

@Entity(tableName = "stocktake_sessions")
data class StocktakeSessionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val startedAt: Long = System.currentTimeMillis(),
    val closedAt: Long? = null,
    val status: StocktakeStatus = StocktakeStatus.IN_PROGRESS,
    val totalItemsChecked: Int = 0,
    val discrepanciesCount: Int = 0,
    val totalVarianceValue: Double = 0.0,
    val notes: String = ""
)

@Entity(tableName = "stocktake_items")
data class StocktakeItemEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sessionId: Long,
    val productId: Long,
    val productName: String,
    val barcode: String,
    val expectedStock: Double,
    val actualCount: Double,
    val variance: Double, // actualCount - expectedStock
    val costPrice: Double,
    val varianceValue: Double // variance * costPrice
)

@Entity(tableName = "customer_debts")
data class CustomerDebtEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerName: String,
    val customerPhone: String,
    val totalDebt: Double,
    val paidAmount: Double = 0.0,
    val remainingDebt: Double,
    val dueDate: Long,
    val invoiceNumber: String = "",
    val customerLocation: String = "",
    val storeAddress: String = "",
    val notes: String = "",
    val lastPaymentDate: Long? = null,
    val isSettled: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val isOverdue: Boolean
        get() = !isSettled && remainingDebt > 0 && dueDate < System.currentTimeMillis()
}

