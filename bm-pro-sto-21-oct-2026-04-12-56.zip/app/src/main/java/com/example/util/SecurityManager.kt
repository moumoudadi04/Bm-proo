package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class SecurityManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("bm_prosto_security_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val PREF_DEVICE_ID = "pref_device_id"
        private const val PREF_IS_ACTIVATED = "pref_is_activated"
        private const val PREF_MASTER_KEY = "pref_master_key"
        private const val PREF_ADMIN_WHATSAPP = "pref_admin_whatsapp"

        // Default initial master key
        const val DEFAULT_MASTER_KEY = "BM2026"
        const val DEFAULT_WHATSAPP = "+213550000000" // Customizable
    }

    private val _isActivatedState = MutableStateFlow(isActivated())
    val isActivatedState: StateFlow<Boolean> = _isActivatedState.asStateFlow()

    private val _adminWhatsAppState = MutableStateFlow(getAdminWhatsApp())
    val adminWhatsAppState: StateFlow<String> = _adminWhatsAppState.asStateFlow()

    init {
        // Ensure device ID is initialized
        if (!prefs.contains(PREF_DEVICE_ID)) {
            val randomSuffix = UUID.randomUUID().toString().take(6).uppercase()
            val deviceModel = Build.MODEL.filter { it.isLetterOrDigit() }.take(4).uppercase()
            val generatedId = "BM-$deviceModel-$randomSuffix"
            prefs.edit().putString(PREF_DEVICE_ID, generatedId).apply()
        }
    }

    fun isActivated(): Boolean {
        return prefs.getBoolean(PREF_IS_ACTIVATED, false)
    }

    fun getDeviceId(): String {
        return prefs.getString(PREF_DEVICE_ID, "BM-DEV-0001") ?: "BM-DEV-0001"
    }

    fun getMasterKey(): String {
        return prefs.getString(PREF_MASTER_KEY, DEFAULT_MASTER_KEY) ?: DEFAULT_MASTER_KEY
    }

    fun getAdminWhatsApp(): String {
        return prefs.getString(PREF_ADMIN_WHATSAPP, DEFAULT_WHATSAPP) ?: DEFAULT_WHATSAPP
    }

    fun setAdminWhatsApp(number: String) {
        prefs.edit().putString(PREF_ADMIN_WHATSAPP, number).apply()
        _adminWhatsAppState.value = number
    }

    /**
     * Verifies the activation key entered by the user upon first install.
     * If valid, marks the app as activated permanently on this device.
     */
    fun verifyAndActivate(enteredKey: String): Boolean {
        val currentMasterKey = getMasterKey()
        val trimmed = enteredKey.trim()
        if (trimmed == currentMasterKey || trimmed == DEFAULT_MASTER_KEY) {
            prefs.edit().putBoolean(PREF_IS_ACTIVATED, true).apply()
            _isActivatedState.value = true
            return true
        }
        return false
    }

    /**
     * Changes the master password/activation key.
     * Requires confirming the old password.
     */
    fun changeMasterKey(oldKey: String, newKey: String): Boolean {
        val currentKey = getMasterKey()
        if (oldKey.trim() == currentKey && newKey.trim().length >= 4) {
            prefs.edit().putString(PREF_MASTER_KEY, newKey.trim()).apply()
            return true
        }
        return false
    }

    /**
     * Resets activation to test or simulate switching to a new phone.
     */
    fun resetActivation() {
        val newSuffix = UUID.randomUUID().toString().take(6).uppercase()
        val newId = "BM-NEW-$newSuffix"
        prefs.edit()
            .putBoolean(PREF_IS_ACTIVATED, false)
            .putString(PREF_DEVICE_ID, newId)
            .apply()
        _isActivatedState.value = false
    }
}
