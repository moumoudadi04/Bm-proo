package com.example.util

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.unit.LayoutDirection

enum class AppLanguage(val code: String, val displayName: String, val layoutDirection: LayoutDirection) {
    ARABIC("ar", "العربية (Arabic)", LayoutDirection.Rtl),
    ENGLISH("en", "English", LayoutDirection.Ltr)
}

val LocalAppLanguage = staticCompositionLocalOf { AppLanguage.ARABIC }

object Strings {
    fun get(key: String, lang: AppLanguage): String {
        val ar = lang == AppLanguage.ARABIC
        return when (key) {
            "app_title" -> if (ar) "إدارة المخزن ProSto" else "ProSto Warehouse"
            "dashboard" -> if (ar) "لوحة التحكم" else "Dashboard"
            "inventory" -> if (ar) "المخزون" else "Inventory"
            "new_invoice" -> if (ar) "فاتورة جديدة" else "New Invoice"
            "stocktake" -> if (ar) "الجرد الدقيق" else "Stocktake Audit"
            "shortages" -> if (ar) "النواقص والتنبيهات" else "Shortage Alerts"
            "reports" -> if (ar) "تقارير الأداء" else "Reports"
            "printer" -> if (ar) "الطابعة الحرارية" else "Thermal Printer"
            "cloud_sync" -> if (ar) "السحابة والتزامن" else "Cloud Sync"
            "settings" -> if (ar) "الإعدادات" else "Settings"

            // Master Startup Key (مفتاح بدء التشغيل)
            "startup_key" -> if (ar) "مفتاح بدء التشغيل" else "Master System Switch"
            "system_active" -> if (ar) "المخزن نشط وقيد العمل" else "Store Session Active"
            "system_idle" -> if (ar) "المخزن مغلق / وضع التوقف" else "Store Session Closed"
            "tap_to_start" -> if (ar) "اضغط لبدء تشغيل الوردية" else "Tap to Start Store Shift"
            "tap_to_stop" -> if (ar) "اضغط لإغلاق الوردية واليومية" else "Tap to Close Store Shift"
            "shift_started_at" -> if (ar) "بدأت الوردية في:" else "Shift started at:"

            // Dashboard Stats
            "total_products" -> if (ar) "إجمالي الأصناف" else "Total Products"
            "stock_value_cost" -> if (ar) "قيمة المخزون (بالتكلفة)" else "Stock Valuation (Cost)"
            "stock_value_sell" -> if (ar) "قيمة المخزون (بالبيع)" else "Stock Valuation (Retail)"
            "potential_profit" -> if (ar) "الربح التقديري المتوقع" else "Expected Gross Profit"
            "today_sales" -> if (ar) "مبيعات اليوم" else "Today's Sales"
            "today_invoices" -> if (ar) "فواتير اليوم" else "Today's Invoices"
            "low_stock_count" -> if (ar) "أصناف منخفضة" else "Low Stock Items"
            "out_of_stock_count" -> if (ar) "أصناف نفدت" else "Out of Stock"
            "quick_actions" -> if (ar) "إجراءات سريعة" else "Quick Actions"
            "recent_movements" -> if (ar) "آخر حركات المخزن" else "Recent Stock Movements"

            // Products
            "search_hint" -> if (ar) "ابحث بالاسم أو الباركود..." else "Search by name or barcode..."
            "add_product" -> if (ar) "إضافة صنف جديد" else "Add New Product"
            "edit_product" -> if (ar) "تعديل الصنف" else "Edit Product"
            "product_name_ar" -> if (ar) "اسم الصنف (بالعربية)" else "Product Name (Arabic)"
            "product_name_en" -> if (ar) "اسم الصنف (بالإنجليزية)" else "Product Name (English)"
            "barcode" -> if (ar) "الباركود / الكود" else "Barcode / SKU"
            "category" -> if (ar) "التصنيف" else "Category"
            "unit" -> if (ar) "الوحدة" else "Unit"
            "cost_price" -> if (ar) "سعر التكلفة" else "Cost Price"
            "sell_price" -> if (ar) "سعر البيع" else "Selling Price"
            "current_stock" -> if (ar) "الرصيد الحالي" else "Current Stock"
            "min_alert_stock" -> if (ar) "حد الطلب والتنبيه" else "Min Alert Level"
            "location" -> if (ar) "موقع الرف / المخزن" else "Shelf / Location"
            "save" -> if (ar) "حفظ البيانات" else "Save"
            "cancel" -> if (ar) "إلغاء" else "Cancel"
            "delete" -> if (ar) "حذف" else "Delete"
            "quantity" -> if (ar) "الكمية" else "Quantity"
            "in_stock" -> if (ar) "متوفر" else "In Stock"
            "low_stock" -> if (ar) "منخفض" else "Low Stock"
            "out_of_stock" -> if (ar) "نفد" else "Out of Stock"

            // Invoices & POS
            "invoice_number" -> if (ar) "رقم الفاتورة" else "Invoice #"
            "customer_name" -> if (ar) "اسم العميل / المورد" else "Customer / Party"
            "customer_phone" -> if (ar) "رقم الهاتف" else "Phone Number"
            "subtotal" -> if (ar) "المجموع الفرعي" else "Subtotal"
            "discount" -> if (ar) "الخصم" else "Discount"
            "tax_15" -> if (ar) "ضريبة القيمة المضافة (15%)" else "VAT (15%)"
            "net_total" -> if (ar) "الصافي الإجمالي" else "Net Total"
            "pay_cash" -> if (ar) "نقداً" else "Cash"
            "pay_card" -> if (ar) "شبكة / بطاقة" else "Card / POS"
            "pay_debt" -> if (ar) "آجل" else "Credit / Debt"
            "complete_and_print" -> if (ar) "إتمام وطباعة الإيصال" else "Complete & Print"
            "print_receipt" -> if (ar) "طباعة حرارية" else "Thermal Print"
            "share_receipt" -> if (ar) "مشاركة الإيصال" else "Share Receipt"
            "close" -> if (ar) "إغلاق" else "Close"
            "cart_empty" -> if (ar) "سلة الفاتورة فارغة" else "Invoice Cart is Empty"
            "add_items" -> if (ar) "أضف أصنافاً للفاتورة" else "Add items to invoice"

            // Stocktake (الجرد الدقيق)
            "stocktake_title" -> if (ar) "جلسات الجرد الدوري" else "Stocktake Sessions"
            "start_new_stocktake" -> if (ar) "بدء جلسة جرد جديدة" else "Start New Stocktake"
            "session_name" -> if (ar) "عنوان جلسة الجرد" else "Stocktake Session Title"
            "expected" -> if (ar) "المسجل" else "Expected"
            "actual" -> if (ar) "الفعلي" else "Actual"
            "variance" -> if (ar) "الفارق" else "Variance"
            "variance_value" -> if (ar) "قيمة العجز/الفائض" else "Variance Value"
            "reconcile_and_apply" -> if (ar) "اعتماد وتسوية المخزن" else "Reconcile & Apply Stock"
            "print_audit_report" -> if (ar) "طباعة تقرير الجرد" else "Print Audit Report"
            "matching" -> if (ar) "مطابق" else "Match"
            "shortage" -> if (ar) "عجز" else "Shortage"
            "surplus" -> if (ar) "فائض" else "Surplus"

            // Shortages (النواقص)
            "shortages_title" -> if (ar) "النواقص وأوامر التوريد" else "Shortages & Reorder List"
            "urgent_shortages" -> if (ar) "أصناف بلغت حد الخطر" else "Items below alert threshold"
            "reorder_qty" -> if (ar) "الكمية المقترحة للطلب" else "Suggested Reorder Qty"
            "quick_restock" -> if (ar) "توريد سريع للمخزن" else "Quick Restock"
            "print_reorder_sheet" -> if (ar) "طباعة أمر شراء للمورد" else "Print Purchase Order"

            // Reports
            "daily_report" -> if (ar) "تقرير المبيعات اليومي (Z-Report)" else "Daily Sales (Z-Report)"
            "total_revenue" -> if (ar) "إجمالي الإيرادات" else "Total Revenue"
            "gross_profit" -> if (ar) "صافي الربح التقديري" else "Gross Profit"
            "top_selling" -> if (ar) "الأصناف الأكثر مبيعاً" else "Top Selling Items"
            "print_z_report" -> if (ar) "طباعة تقرير Z الحراري" else "Print Thermal Z-Report"

            // Printer Settings
            "printer_settings" -> if (ar) "إعدادات الطابعة الحرارية" else "Thermal Printer Setup"
            "paper_width" -> if (ar) "مقاس رول الورق" else "Paper Roll Size"
            "printer_status" -> if (ar) "حالة الاتصال بالطابعة" else "Printer Connection"
            "connected" -> if (ar) "متصلة وجاهزة" else "Connected & Ready"
            "disconnected" -> if (ar) "غير متصلة" else "Disconnected"
            "test_print" -> if (ar) "طباعة إيصال تجريبي" else "Test Print Receipt"
            "store_info_custom" -> if (ar) "بيانات المتجر والترويسة" else "Store & Header Info"

            // Cloud Sync
            "cloud_database" -> if (ar) "قاعدة البيانات السحابية" else "Cloud Database & Sync"
            "sync_status" -> if (ar) "حالة المزامنة السحابية" else "Cloud Sync Status"
            "synced_just_now" -> if (ar) "متزامن سحابياً بالكامل" else "Fully Synced to Cloud"
            "sync_now" -> if (ar) "مزامنة الآن مع السحابة" else "Sync with Cloud Now"
            "backup_json" -> if (ar) "تصدير نسخة احتياطية سحابية" else "Export Cloud Backup"
            "restore_json" -> if (ar) "استعادة من السحابة" else "Restore from Cloud"

            // Currency
            "currency" -> if (ar) "ر.س" else "SAR"

            else -> key
        }
    }
}
