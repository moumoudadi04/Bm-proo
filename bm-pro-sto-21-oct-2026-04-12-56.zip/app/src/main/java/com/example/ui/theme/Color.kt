package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ProTeal = Color(0xFF0D9488)
val ProTealDark = Color(0xFF0F766E)
val ProTealLight = Color(0xFF2DD4BF)

val ProSlate900 = Color(0xFF0F172A)
val ProSlate800 = Color(0xFF1E293B)
val ProSlate700 = Color(0xFF334155)
val ProSlate100 = Color(0xFFF1F5F9)
val ProSlate50 = Color(0xFFF8FAFC)

val ProAmber = Color(0xFFD97706)
val ProAmberLight = Color(0xFFFDE68A)

val ProRed = Color(0xFFDC2626)
val ProGreen = Color(0xFF16A34A)
val ProBlue = Color(0xFF2563EB)
