package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.ProductEntity
import com.example.ui.MainViewModel
import com.example.ui.components.StockStatusBadge
import com.example.ui.theme.ProRed
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings
import java.util.Locale

@Composable
fun ProductsScreen(
    viewModel: MainViewModel,
    currentLanguage: AppLanguage
) {
    val products by viewModel.filteredProducts.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val isDialogOpen by viewModel.isProductDialogOpen.collectAsState()
    val editingProduct by viewModel.editingProduct.collectAsState()

    var showRestockDialogFor by remember { mutableStateOf<ProductEntity?>(null) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { viewModel.openAddProductDialog(null) },
                containerColor = ProTeal,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_product")
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = Strings.get("add_product", currentLanguage))
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Search Bar
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text(Strings.get("search_hint", currentLanguage)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                            Icon(Icons.Default.Close, contentDescription = null)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_products_input")
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Count summary
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "${products.size} ${Strings.get("inventory", currentLanguage)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Products List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 80.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(products, key = { it.id }) { product ->
                    ProductCardItem(
                        product = product,
                        currentLanguage = currentLanguage,
                        onEdit = { viewModel.openAddProductDialog(product) },
                        onQuickRestock = { showRestockDialogFor = product },
                        onDelete = { viewModel.deleteProduct(product.id) }
                    )
                }
            }
        }
    }

    // Add / Edit Product Dialog
    if (isDialogOpen) {
        ProductEditDialog(
            product = editingProduct,
            currentLanguage = currentLanguage,
            onDismiss = { viewModel.closeProductDialog() },
            onSave = { viewModel.saveProduct(it) }
        )
    }

    // Quick Restock Dialog
    showRestockDialogFor?.let { product ->
        QuickRestockDialog(
            product = product,
            currentLanguage = currentLanguage,
            onDismiss = { showRestockDialogFor = null },
            onRestock = { qty ->
                viewModel.quickRestock(product.id, qty)
                showRestockDialogFor = null
            }
        )
    }
}

@Composable
fun ProductCardItem(
    product: ProductEntity,
    currentLanguage: AppLanguage,
    onEdit: () -> Unit,
    onQuickRestock: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.nameAr,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = product.nameEn,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                StockStatusBadge(
                    currentStock = product.currentStock,
                    minAlertStock = product.minAlertStock,
                    currentLanguage = currentLanguage
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "باركود: ${product.barcode}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "موقع: ${product.location}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Column {
                        Text(text = "سعر البيع", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "${String.format(Locale.US, "%.2f", product.sellPrice)} ${Strings.get("currency", currentLanguage)}",
                            fontWeight = FontWeight.Bold,
                            color = ProTeal,
                            fontSize = 14.sp
                        )
                    }
                    Column {
                        Text(text = "التكلفة", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "${String.format(Locale.US, "%.2f", product.costPrice)} ${Strings.get("currency", currentLanguage)}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Button(
                        onClick = onQuickRestock,
                        colors = ButtonDefaults.buttonColors(containerColor = ProTeal.copy(alpha = 0.15f), contentColor = ProTeal),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(text = "+ توريد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ProRed.copy(alpha = 0.7f))
                    }
                }
            }
        }
    }
}

@Composable
fun ProductEditDialog(
    product: ProductEntity?,
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (ProductEntity) -> Unit
) {
    var nameAr by remember { mutableStateOf(product?.nameAr ?: "") }
    var nameEn by remember { mutableStateOf(product?.nameEn ?: "") }
    var barcode by remember { mutableStateOf(product?.barcode ?: "628${System.currentTimeMillis() % 1000000000}") }
    var category by remember { mutableStateOf(product?.category ?: "أصناف عامة / General") }
    var unit by remember { mutableStateOf(product?.unit ?: "قطعة / Pcs") }
    var costPrice by remember { mutableStateOf(product?.costPrice?.toString() ?: "0.0") }
    var sellPrice by remember { mutableStateOf(product?.sellPrice?.toString() ?: "0.0") }
    var currentStock by remember { mutableStateOf(product?.currentStock?.toString() ?: "10.0") }
    var minAlertStock by remember { mutableStateOf(product?.minAlertStock?.toString() ?: "5.0") }
    var location by remember { mutableStateOf(product?.location ?: "A-01") }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = if (product == null) Strings.get("add_product", currentLanguage) else Strings.get("edit_product", currentLanguage),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = null)
                    }
                }

                OutlinedTextField(
                    value = nameAr,
                    onValueChange = { nameAr = it },
                    label = { Text(Strings.get("product_name_ar", currentLanguage)) },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = nameEn,
                    onValueChange = { nameEn = it },
                    label = { Text(Strings.get("product_name_en", currentLanguage)) },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = barcode,
                        onValueChange = { barcode = it },
                        label = { Text(Strings.get("barcode", currentLanguage)) },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = { Text(Strings.get("location", currentLanguage)) },
                        modifier = Modifier.weight(0.7f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = costPrice,
                        onValueChange = { costPrice = it },
                        label = { Text(Strings.get("cost_price", currentLanguage)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sellPrice,
                        onValueChange = { sellPrice = it },
                        label = { Text(Strings.get("sell_price", currentLanguage)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = currentStock,
                        onValueChange = { currentStock = it },
                        label = { Text(Strings.get("current_stock", currentLanguage)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = minAlertStock,
                        onValueChange = { minAlertStock = it },
                        label = { Text(Strings.get("min_alert_stock", currentLanguage)) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = {
                            val entity = ProductEntity(
                                id = product?.id ?: 0L,
                                barcode = barcode.ifBlank { "628${System.currentTimeMillis() % 1000000}" },
                                nameAr = nameAr.ifBlank { "صنف غير مسمى" },
                                nameEn = nameEn.ifBlank { "Unnamed item" },
                                category = category,
                                unit = unit,
                                costPrice = costPrice.toDoubleOrNull() ?: 0.0,
                                sellPrice = sellPrice.toDoubleOrNull() ?: 0.0,
                                currentStock = currentStock.toDoubleOrNull() ?: 0.0,
                                minAlertStock = minAlertStock.toDoubleOrNull() ?: 5.0,
                                location = location
                            )
                            onSave(entity)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = Strings.get("save", currentLanguage))
                    }

                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(text = Strings.get("cancel", currentLanguage))
                    }
                }
            }
        }
    }
}

@Composable
fun QuickRestockDialog(
    product: ProductEntity,
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onRestock: (Double) -> Unit
) {
    var addedQty by remember { mutableStateOf("10") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "توريد سريع للمخزن",
                    fontWeight = FontWeight.Bold,
                    fontSize = 17.sp
                )
                Text(
                    text = product.nameAr,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "الرصيد الحالي بالمخزن: ${product.currentStock}",
                    fontSize = 12.sp,
                    color = ProTeal,
                    fontWeight = FontWeight.Bold
                )

                OutlinedTextField(
                    value = addedQty,
                    onValueChange = { addedQty = it },
                    label = { Text("الكمية الواردة الإضافية") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            val qty = addedQty.toDoubleOrNull() ?: 0.0
                            if (qty > 0) onRestock(qty)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("إضافة للرصيد")
                    }
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text(Strings.get("cancel", currentLanguage))
                    }
                }
            }
        }
    }
}
