package com.example.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.InvoiceEntity
import com.example.ui.MainViewModel
import com.example.ui.components.StatCard
import com.example.ui.theme.ProAmber
import com.example.ui.theme.ProBlue
import com.example.ui.theme.ProGreen
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    viewModel: MainViewModel,
    currentLanguage: AppLanguage
) {
    val invoices by viewModel.allInvoices.collectAsState()
    val totalCost by viewModel.totalCostValue.collectAsState()
    val totalSell by viewModel.totalSellValue.collectAsState()

    val totalSales = invoices.sumOf { it.totalAmount }
    val totalInvoicesCount = invoices.size
    val costVal = totalCost ?: 0.0
    val sellVal = totalSell ?: 0.0
    val expectedProfit = (sellVal - costVal).coerceAtLeast(0.0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = Strings.get("reports", currentLanguage),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "تحليلات الأداء اليومي والمبيعات وجرد الأرباح",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Button(
                    onClick = {
                        val sb = StringBuilder()
                        val width = 32
                        val div = "-".repeat(width)
                        sb.append("      تقرير المبيعات Z-Report    \n")
                        sb.append("   ${viewModel.printerConfig.value.storeName}\n")
                        sb.append(div).append("\n")
                        sb.append("تاريخ التقرير: ${SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date())}\n")
                        sb.append("إجمالي الفواتير: $totalInvoicesCount\n")
                        sb.append("إجمالي المبيعات: ${String.format(Locale.US, "%.2f", totalSales)} ر.س\n")
                        sb.append("تقييم المخزون (تكلفة): ${String.format(Locale.US, "%.2f", costVal)} ر.س\n")
                        sb.append("تقييم المخزون (بيع): ${String.format(Locale.US, "%.2f", sellVal)} ر.س\n")
                        sb.append(div).append("\n")
                        sb.append("نهاية التقرير اليومي Z\n\n\n")

                        // Show in dialog
                        viewModel.triggerTestPrint()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("print_z_report_btn")
                ) {
                    Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = Strings.get("print_z_report", currentLanguage), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Metrics
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = Strings.get("total_revenue", currentLanguage),
                        value = "${String.format(Locale.US, "%.1f", totalSales)} ${Strings.get("currency", currentLanguage)}",
                        subtitle = "$totalInvoicesCount فاتورة منفذة",
                        icon = Icons.Default.PointOfSale,
                        accentColor = ProGreen,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = Strings.get("gross_profit", currentLanguage),
                        value = "${String.format(Locale.US, "%.1f", expectedProfit)} ${Strings.get("currency", currentLanguage)}",
                        subtitle = "ربح إجمالي تقديري",
                        icon = Icons.Default.TrendingUp,
                        accentColor = ProTeal,
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        title = Strings.get("stock_value_cost", currentLanguage),
                        value = "${String.format(Locale.US, "%.0f", costVal)} ${Strings.get("currency", currentLanguage)}",
                        subtitle = "قيمة التكلفة للمخزون",
                        icon = Icons.Default.MonetizationOn,
                        accentColor = ProAmber,
                        modifier = Modifier.weight(1f)
                    )
                    StatCard(
                        title = Strings.get("stock_value_sell", currentLanguage),
                        value = "${String.format(Locale.US, "%.0f", sellVal)} ${Strings.get("currency", currentLanguage)}",
                        subtitle = "القيمة البيعية للمخزون",
                        icon = Icons.Default.Assessment,
                        accentColor = ProBlue,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Invoice History Section
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "سجل الفواتير الصادرة (${invoices.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "اضغط على الفاتورة لإعادة طباعة الإيصال",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        items(invoices) { inv ->
            InvoiceHistoryCard(
                invoice = inv,
                currentLanguage = currentLanguage,
                onClick = { viewModel.viewInvoiceReceipt(inv) }
            )
        }
    }
}

@Composable
fun InvoiceHistoryCard(
    invoice: InvoiceEntity,
    currentLanguage: AppLanguage,
    onClick: () -> Unit
) {
    val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(14.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Receipt,
                contentDescription = null,
                tint = ProTeal,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${invoice.invoiceNumber} • ${invoice.partyName}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = "${dateFormat.format(Date(invoice.timestamp))} • ${invoice.paymentMethod.name}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${String.format(Locale.US, "%.2f", invoice.totalAmount)} ${Strings.get("currency", currentLanguage)}",
                    fontWeight = FontWeight.Bold,
                    color = ProTeal,
                    fontSize = 14.sp
                )
                Text(
                    text = "عرض وطباعة",
                    fontSize = 11.sp,
                    color = ProBlue,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}
