package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.printer.PrinterConnectionType
import com.example.printer.PrinterPaperWidth
import com.example.ui.MainViewModel
import com.example.ui.theme.ProBlue
import com.example.ui.theme.ProGreen
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings

@Composable
fun PrinterSettingsScreen(
    viewModel: MainViewModel,
    currentLanguage: AppLanguage
) {
    val config by viewModel.printerConfig.collectAsState()

    var storeName by remember(config) { mutableStateOf(config.storeName) }
    var storeAddress by remember(config) { mutableStateOf(config.storeAddress) }
    var storePhone by remember(config) { mutableStateOf(config.storePhone) }
    var taxNumber by remember(config) { mutableStateOf(config.taxNumber) }
    var footerMessage by remember(config) { mutableStateOf(config.footerMessage) }
    var paperWidth by remember(config) { mutableStateOf(config.paperWidth) }
    var autoCut by remember(config) { mutableStateOf(config.autoCutPaper) }
    var connectionType by remember(config) { mutableStateOf(config.connectionType) }
    var wifiIp by remember(config) { mutableStateOf(config.wifiIpAddress) }
    var wifiPort by remember(config) { mutableStateOf(config.wifiPort.toString()) }
    var currency by remember(config) { mutableStateOf(config.currencySymbol) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // BM Brand Header
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(16.dp)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_bm_truck_logo),
                    contentDescription = "BM Logistics Logo",
                    modifier = Modifier
                        .size(54.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(14.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "نظام BM المعتمد دولياً لطابعات الفواتير",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "يدعم طابعات البلوتوث والواي فاي والشبكة وشاحنات التوزيع",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Connection Mode Selector: Bluetooth vs Wi-Fi LAN vs System Print
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "نوع اتصال الطابعة الحرارية (Bluetooth / Wi-Fi)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    FilterChip(
                        selected = connectionType == PrinterConnectionType.BLUETOOTH,
                        onClick = {
                            connectionType = PrinterConnectionType.BLUETOOTH
                            viewModel.updatePrinterConfig(config.copy(connectionType = PrinterConnectionType.BLUETOOTH))
                        },
                        leadingIcon = { Icon(Icons.Default.Bluetooth, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("بلوتوث BT") }
                    )

                    FilterChip(
                        selected = connectionType == PrinterConnectionType.WIFI_LAN,
                        onClick = {
                            connectionType = PrinterConnectionType.WIFI_LAN
                            viewModel.updatePrinterConfig(config.copy(connectionType = PrinterConnectionType.WIFI_LAN))
                        },
                        leadingIcon = { Icon(Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("واي فاي Wi-Fi / IP") }
                    )

                    FilterChip(
                        selected = connectionType == PrinterConnectionType.SYSTEM_PRINT,
                        onClick = {
                            connectionType = PrinterConnectionType.SYSTEM_PRINT
                            viewModel.updatePrinterConfig(config.copy(connectionType = PrinterConnectionType.SYSTEM_PRINT))
                        },
                        leadingIcon = { Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp)) },
                        label = { Text("نظام أندرويد") }
                    )
                }

                // If Wi-Fi selected, show IP & Port configuration
                if (connectionType == PrinterConnectionType.WIFI_LAN) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = wifiIp,
                            onValueChange = { wifiIp = it },
                            label = { Text("عنوان IP للطابعة بالشبكة") },
                            modifier = Modifier.weight(1.4f)
                        )
                        OutlinedTextField(
                            value = wifiPort,
                            onValueChange = { wifiPort = it },
                            label = { Text("المنفذ Port") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.6f)
                        )
                    }
                }

                // Status & Test Print
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(ProGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (connectionType == PrinterConnectionType.BLUETOOTH) "متصلة بالبلوتوث (جاهزة)" else "متصلة بشبكة الواي فاي (جاهزة)",
                            color = ProGreen,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { viewModel.triggerTestPrint() },
                        colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("test_print_btn")
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = "فحص وطباعة تجريبية", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Paper Roll Width & Auto-Cut
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = Strings.get("paper_width", currentLanguage), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    FilterChip(
                        selected = paperWidth == PrinterPaperWidth.WIDTH_58MM,
                        onClick = {
                            paperWidth = PrinterPaperWidth.WIDTH_58MM
                            viewModel.updatePrinterConfig(config.copy(paperWidth = PrinterPaperWidth.WIDTH_58MM))
                        },
                        label = { Text("58mm (شاحنات التوزيع والمتنقلة)") }
                    )
                    FilterChip(
                        selected = paperWidth == PrinterPaperWidth.WIDTH_80MM,
                        onClick = {
                            paperWidth = PrinterPaperWidth.WIDTH_80MM
                            viewModel.updatePrinterConfig(config.copy(paperWidth = PrinterPaperWidth.WIDTH_80MM))
                        },
                        label = { Text("80mm (مخازن ومنافذ بيع كبيرة)") }
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "قص الورق الأوتوماتيكي (Auto Cut)", fontSize = 13.sp)
                    Switch(
                        checked = autoCut,
                        onCheckedChange = {
                            autoCut = it
                            viewModel.updatePrinterConfig(config.copy(autoCutPaper = it))
                        }
                    )
                }
            }
        }

        // International Currency Selector
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "العملة الدولية المعتمدة للفواتير", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ر.س", "$ USD", "€ EUR", "د.إ AED", "د.ج DZD", "ج.م EGP").forEach { curr ->
                        FilterChip(
                            selected = currency == curr,
                            onClick = {
                                currency = curr
                                viewModel.updatePrinterConfig(config.copy(currencySymbol = curr))
                            },
                            label = { Text(curr) }
                        )
                    }
                }
            }
        }

        // Receipt Customization with BM Identity
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(text = "ترويسة الفاتورة وبيانات شاحنات BM", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                OutlinedTextField(
                    value = storeName,
                    onValueChange = { storeName = it },
                    label = { Text("اسم المؤسسة أو أسطول التوزيع") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = storeAddress,
                    onValueChange = { storeAddress = it },
                    label = { Text("العنوان والمركز اللوجستي") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = storePhone,
                    onValueChange = { storePhone = it },
                    label = { Text("رقم الهاتف الدولي / واتساب المبيعات") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = taxNumber,
                    onValueChange = { taxNumber = it },
                    label = { Text("الرقم الضريبي الدولي / السجل التجاري") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = footerMessage,
                    onValueChange = { footerMessage = it },
                    label = { Text("رسالة الشكر والضمان الدولي بأسفل الفاتورة") },
                    modifier = Modifier.fillMaxWidth()
                )

                Button(
                    onClick = {
                        val updated = config.copy(
                            storeName = storeName,
                            storeAddress = storeAddress,
                            storePhone = storePhone,
                            taxNumber = taxNumber,
                            footerMessage = footerMessage,
                            paperWidth = paperWidth,
                            autoCutPaper = autoCut,
                            connectionType = connectionType,
                            wifiIpAddress = wifiIp,
                            wifiPort = wifiPort.toIntOrNull() ?: 9100,
                            currencySymbol = currency
                        )
                        viewModel.updatePrinterConfig(updated)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "حفظ إعدادات BM والطابعة الحرارية", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
