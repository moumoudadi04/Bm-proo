package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = ProTealLight,
    onPrimary = ProSlate900,
    primaryContainer = ProTealDark,
    onPrimaryContainer = Color.White,
    secondary = ProTealLight,
    onSecondary = ProSlate900,
    background = ProSlate900,
    onBackground = Color.White,
    surface = ProSlate800,
    onSurface = Color.White,
    surfaceVariant = ProSlate700,
    onSurfaceVariant = ProSlate100,
    error = ProRed,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = ProTeal,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCCFBF1),
    onPrimaryContainer = ProTealDark,
    secondary = ProSlate700,
    onSecondary = Color.White,
    background = ProSlate50,
    onBackground = ProSlate900,
    surface = Color.White,
    onSurface = ProSlate900,
    surfaceVariant = ProSlate100,
    onSurfaceVariant = ProSlate700,
    error = ProRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep ProSto brand colors consistent
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
