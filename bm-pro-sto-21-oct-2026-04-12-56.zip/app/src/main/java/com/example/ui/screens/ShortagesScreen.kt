package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductEntity
import com.example.ui.MainViewModel
import com.example.ui.components.StockStatusBadge
import com.example.ui.theme.ProAmber
import com.example.ui.theme.ProGreen
import com.example.ui.theme.ProRed
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ShortagesScreen(
    viewModel: MainViewModel,
    currentLanguage: AppLanguage
) {
    val lowStockList by viewModel.lowStockProducts.collectAsState()
    val context = LocalContext.current

    var showRestockFor by remember { mutableStateOf<ProductEntity?>(null) }

    val outOfStockCount = lowStockList.count { it.currentStock <= 0 }
    val lowCount = lowStockList.count { it.currentStock > 0 }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = Strings.get("shortages_title", currentLanguage),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = "متابعة النواقص وإصدار طلبات التوريد والشراء",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (lowStockList.isNotEmpty()) {
                Button(
                    onClick = {
                        val sb = StringBuilder()
                        sb.append("=== أمر شراء وتوريد نواقص المخزن ===\n")
                        sb.append("تاريخ الطلب: ${SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()).format(Date())}\n")
                        sb.append("--------------------------------\n")
                        for (p in lowStockList) {
                            val suggestReorder = (p.minAlertStock * 2) - p.currentStock
                            sb.append("• ${p.nameAr}\n")
                            sb.append("  الرصيد الحالي: ${p.currentStock} ${p.unit} | المطلوب توريده: ${suggestReorder.toInt()} ${p.unit}\n")
                        }
                        sb.append("--------------------------------\n")
                        sb.append("مرسل من نظام ProSto للمخازن")

                        val shareIntent = Intent().apply {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_TEXT, sb.toString())
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "إرسال أمر التوريد للمورد"))
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ProAmber),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.testTag("share_reorder_sheet_btn")
                ) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "مشاركة أمر الشراء", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Summary Metric Cards
        Row(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "أصناف نفدت بالكامل", fontSize = 11.sp, color = ProRed, fontWeight = FontWeight.SemiBold)
                    Text(text = "$outOfStockCount", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ProRed)
                }
            }

            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF3C7)),
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "أوشكت على النفاد", fontSize = 11.sp, color = ProAmber, fontWeight = FontWeight.SemiBold)
                    Text(text = "$lowCount", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = ProAmber)
                }
            }
        }

        // List
        if (lowStockList.isEmpty()) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = ProGreen,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "المخزون ممتاز وفي المستويات الآمنة!",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "لا توجد أي نواقص أو أصناف تحت حد الطلب حالياً",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(lowStockList, key = { it.id }) { product ->
                    ShortageProductCard(
                        product = product,
                        currentLanguage = currentLanguage,
                        onRestock = { showRestockFor = product }
                    )
                }
            }
        }
    }

    showRestockFor?.let { product ->
        QuickRestockDialog(
            product = product,
            currentLanguage = currentLanguage,
            onDismiss = { showRestockFor = null },
            onRestock = { qty ->
                viewModel.quickRestock(product.id, qty)
                showRestockFor = null
            }
        )
    }
}

@Composable
fun ShortageProductCard(
    product: ProductEntity,
    currentLanguage: AppLanguage,
    onRestock: () -> Unit
) {
    val suggestedOrder = ((product.minAlertStock * 2) - product.currentStock).coerceAtLeast(5.0)

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.nameAr,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "الموقع: ${product.location} • باركود: ${product.barcode}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                StockStatusBadge(
                    currentStock = product.currentStock,
                    minAlertStock = product.minAlertStock,
                    currentLanguage = currentLanguage
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(text = "الرصيد / حد التنبيه", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${product.currentStock} / ${product.minAlertStock} ${product.unit}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }

                Button(
                    onClick = onRestock,
                    colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "إضافة توريد (+${suggestedOrder.toInt()})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
