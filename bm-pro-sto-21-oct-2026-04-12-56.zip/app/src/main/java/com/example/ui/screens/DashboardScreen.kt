package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.MoveToInbox
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.MovementType
import com.example.data.model.ProductEntity
import com.example.data.model.StockMovementEntity
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.theme.ProAmber
import com.example.ui.theme.ProBlue
import com.example.ui.theme.ProGreen
import com.example.ui.theme.ProRed
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DashboardScreen(
    viewModel: MainViewModel,
    currentLanguage: AppLanguage
) {
    val shiftState by viewModel.shiftState.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()
    val totalCount by viewModel.totalProductCount.collectAsState()
    val totalCost by viewModel.totalCostValue.collectAsState()
    val totalSell by viewModel.totalSellValue.collectAsState()
    val lowStockList by viewModel.lowStockProducts.collectAsState()
    val overdueDebts by viewModel.overdueDebts.collectAsState()
    val invoices by viewModel.allInvoices.collectAsState()
    val movements by viewModel.recentMovements.collectAsState()

    var showRestockDialog by remember { mutableStateOf(false) }

    val todaySales = invoices.sumOf { it.totalAmount }
    val costVal = totalCost ?: 0.0
    val sellVal = totalSell ?: 0.0
    val expectedProfit = (sellVal - costVal).coerceAtLeast(0.0)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        contentPadding = PaddingValues(vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Classic Brand Header with Gold BM Logo & Distribution Truck
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(14.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_bm_gold_logo),
                        contentDescription = "BM Gold Logo",
                        modifier = Modifier
                            .size(52.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, ProAmber, CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "إدارة المخزن والمبيعات",
                                fontWeight = FontWeight.Black,
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = ProTeal.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "BM ProSto",
                                    fontSize = 11.sp,
                                    color = ProTeal,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "نظام إدارة المخازن الكلاسيكي، الفواتير، وشاحنات التوزيع",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 2. Classic Master Startup Key Banner (مفتاح بدء التشغيل الكلاسيكي)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (shiftState.isActive) Color(0xFFECFDF5) else Color(0xFFFEF2F2)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.toggleStartupKey() }
                    .testTag("classic_startup_key_banner")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(if (shiftState.isActive) ProGreen else ProRed),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = "Startup Key",
                            tint = Color.White,
                            modifier = Modifier.size(26.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "مفتاح بدء التشغيل: ",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (shiftState.isActive) "الوردية مفتوحة ونشطة 🟢" else "الوردية متوقفة ومغلقة 🔴",
                                fontWeight = FontWeight.Black,
                                fontSize = 13.sp,
                                color = if (shiftState.isActive) ProGreen else ProRed
                            )
                        }
                        Text(
                            text = if (shiftState.isActive) {
                                "المسؤول: ${shiftState.cashierName} • اضغط لإغلاق الوردية واليومية"
                            } else {
                                "اضغط لتشغيل المخزن وبدء وردية العمل اليومية"
                            },
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // 3. Classic Quick Stats Strip (شريط إحصائيات المخزن والمبيعات)
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp, horizontal = 8.dp),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ClassicMiniStat(
                        label = "الأصناف",
                        value = "$totalCount",
                        color = ProBlue,
                        onClick = { viewModel.navigateTo(Screen.PRODUCTS) }
                    )
                    Box(modifier = Modifier.width(1.dp).height(28.dp).background(Color(0xFFE2E8F0)))
                    ClassicMiniStat(
                        label = "مبيعات اليوم",
                        value = "${String.format(Locale.US, "%.0f", todaySales)} ر.س",
                        color = ProGreen,
                        onClick = { viewModel.navigateTo(Screen.REPORTS) }
                    )
                    Box(modifier = Modifier.width(1.dp).height(28.dp).background(Color(0xFFE2E8F0)))
                    ClassicMiniStat(
                        label = "النواقص",
                        value = "${lowStockList.size}",
                        color = if (lowStockList.isNotEmpty()) ProRed else ProTeal,
                        onClick = { viewModel.navigateTo(Screen.SHORTAGES) }
                    )
                    Box(modifier = Modifier.width(1.dp).height(28.dp).background(Color(0xFFE2E8F0)))
                    ClassicMiniStat(
                        label = "ديون متأخرة",
                        value = "${overdueDebts.size}",
                        color = if (overdueDebts.isNotEmpty()) ProAmber else Color.Gray,
                        onClick = { viewModel.navigateTo(Screen.DEBTS) }
                    )
                }
            }
        }

        // 4. THE ICONIC CLASSIC MENU GRID (شبكة الأزرار الكبيرة لتطبيق إدارة المخزن القديم)
        item {
            Text(
                text = "قائمة إدارة المخزن الرئيسية",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
            )
        }

        // Row 1: المنتجات والمخزون + فاتورة بيع جديدة
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                ClassicMenuTile(
                    title = "المخزون والسلع",
                    subtitle = "إضافة صنف، الباركود والأسعار",
                    badge = "$totalCount صنف",
                    icon = Icons.Default.Inventory,
                    iconBgColor = Color(0xFF0284C7), // Classic Blue
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(Screen.PRODUCTS) }
                )
                ClassicMenuTile(
                    title = "فاتورة بيع (POS)",
                    subtitle = "بيع سريع وطباعة حرارية",
                    badge = "نقطة بيع ⚡",
                    icon = Icons.Default.PointOfSale,
                    iconBgColor = Color(0xFF059669), // Classic Emerald Green
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(Screen.NEW_INVOICE) }
                )
            }
        }

        // Row 2: توريد بضاعة للمخزن + سجل الديون والزبائن
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                ClassicMenuTile(
                    title = "توريد بضاعة",
                    subtitle = "إدخال كميات واردة للمخزن",
                    badge = "إدخال فوري 📥",
                    icon = Icons.Default.MoveToInbox,
                    iconBgColor = Color(0xFF4F46E5), // Classic Indigo
                    modifier = Modifier.weight(1f),
                    onClick = { showRestockDialog = true }
                )
                ClassicMenuTile(
                    title = "الديون والزبائن",
                    subtitle = "متابعة الذمم وGoogle Maps",
                    badge = if (overdueDebts.isNotEmpty()) "${overdueDebts.size} متأخر ⚠️" else "سجل الديون",
                    icon = Icons.Default.MonetizationOn,
                    iconBgColor = Color(0xFFD97706), // Classic Amber
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(Screen.DEBTS) }
                )
            }
        }

        // Row 3: إشعارات النواقص + جرد المخزن
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                ClassicMenuTile(
                    title = "سجل النواقص",
                    subtitle = "الأصناف المنتهية والتحذيرات",
                    badge = if (lowStockList.isNotEmpty()) "${lowStockList.size} ناقص ⚠️" else "المخزون مكتمل ✅",
                    icon = Icons.Default.NotificationsActive,
                    iconBgColor = Color(0xFFDC2626), // Classic Crimson Red
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(Screen.SHORTAGES) }
                )
                ClassicMenuTile(
                    title = "جرد المخزن",
                    subtitle = "مطابقة الفعلي وحساب الفارق",
                    badge = "جرد وتدقيق",
                    icon = Icons.Default.Assessment,
                    iconBgColor = Color(0xFF7C3AED), // Classic Violet
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(Screen.STOCKTAKE) }
                )
            }
        }

        // Row 4: التقارير اليومية + الطابعة الحرارية
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                ClassicMenuTile(
                    title = "تقارير الأرباح",
                    subtitle = "المبيعات ورأس مال المخزن",
                    badge = "يومية المخزن",
                    icon = Icons.Default.QueryStats,
                    iconBgColor = Color(0xFF0D9488), // Classic Teal
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(Screen.REPORTS) }
                )
                ClassicMenuTile(
                    title = "الطابعة الحرارية",
                    subtitle = "ربط Bluetooth و Wi-Fi",
                    badge = "ESC/POS 58/80",
                    icon = Icons.Default.Print,
                    iconBgColor = Color(0xFF475569), // Classic Slate
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(Screen.PRINTER_SETTINGS) }
                )
            }
        }

        // Row 5: النسخ الاحتياطي السحابي + أمان وكلمة السر
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
                ClassicMenuTile(
                    title = "النسخ السحابي",
                    subtitle = "حفظ واسترجاع البيانات",
                    badge = "سحابي ☁️",
                    icon = Icons.Default.CloudSync,
                    iconBgColor = Color(0xFF0891B2), // Classic Cyan
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(Screen.CLOUD_SYNC) }
                )
                ClassicMenuTile(
                    title = "أمان وكلمة السر",
                    subtitle = "تغيير الرمز ورقم الواتساب",
                    badge = "ترخيص BM",
                    icon = Icons.Default.Key,
                    iconBgColor = Color(0xFFB45309), // Classic Dark Gold
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.openSecuritySettings() }
                )
            }
        }

        // 5. Recent Movements Section
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "آخر الحركات المخزنية المسجلة",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "${movements.size} حركة",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        if (movements.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "لا توجد حركات مخزنية حديثة مسجلة بعد",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            items(movements.take(8)) { mov ->
                MovementItemRow(movement = mov, currentLanguage = currentLanguage)
            }
        }
    }

    // Quick Inward Restock Dialog
    if (showRestockDialog) {
        QuickInwardRestockDialog(
            products = allProducts,
            onDismiss = { showRestockDialog = false },
            onConfirm = { prodId, qty ->
                viewModel.quickRestock(prodId, qty)
                showRestockDialog = false
            }
        )
    }
}

/**
 * Classic Mini Stat item for the summary ribbon
 */
@Composable
private fun ClassicMiniStat(
    label: String,
    value: String,
    color: Color,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 2.dp)
    ) {
        Text(
            text = value,
            fontWeight = FontWeight.Black,
            fontSize = 14.sp,
            color = color
        )
        Text(
            text = label,
            fontSize = 10.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontWeight = FontWeight.Medium
        )
    }
}

/**
 * Big Iconic Classic Menu Tile (مثل تطبيق إدارة المخزن القديم تماماً)
 */
@Composable
private fun ClassicMenuTile(
    title: String,
    subtitle: String,
    badge: String,
    icon: ImageVector,
    iconBgColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .height(138.dp)
            .clickable(onClick = onClick)
            .testTag("classic_tile_${title.replace(" ", "_")}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Row: Icon + Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(iconBgColor),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = iconBgColor.copy(alpha = 0.12f)
                ) {
                    Text(
                        text = badge,
                        color = iconBgColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Bottom Text
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

/**
 * Quick Inward Restock Dialog (توريد وإدخال بضاعة للمخزن)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QuickInwardRestockDialog(
    products: List<ProductEntity>,
    onDismiss: () -> Unit,
    onConfirm: (Long, Double) -> Unit
) {
    val context = LocalContext.current
    var selectedProduct by remember { mutableStateOf(products.firstOrNull()) }
    var expanded by remember { mutableStateOf(false) }
    var qtyText by remember { mutableStateOf("10") }
    var notesText by remember { mutableStateOf("فاتورة توريد واردة") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF4F46E5)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MoveToInbox,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "توريد بضاعة جديدة للمخزن",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "إضافة كميات واردة وتحديث رصيد الصنف فورا",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Product Selection Dropdown
                if (products.isEmpty()) {
                    Text("لا توجد منتجات مسجلة بالمخزن بعد. يرجى إضافة صنف أولا.")
                } else {
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = selectedProduct?.let { "${it.nameAr} (الرصيد: ${it.currentStock})" } ?: "اختر الصنف",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("الصنف المراد توريده") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier.menuAnchor().fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            products.forEach { prod ->
                                DropdownMenuItem(
                                    text = { Text("${prod.nameAr} - رصيد حالي: ${prod.currentStock}") },
                                    onClick = {
                                        selectedProduct = prod
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    // Quantity Input
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { qtyText = it },
                        label = { Text("الكمية الموردة") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Notes
                    OutlinedTextField(
                        value = notesText,
                        onValueChange = { notesText = it },
                        label = { Text("ملاحظات التوريد / رقم السند") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Button(
                            onClick = onDismiss,
                            colors = ButtonDefaults.outlinedButtonColors(),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء")
                        }

                        Button(
                            onClick = {
                                val prod = selectedProduct
                                val qty = qtyText.toDoubleOrNull()
                                if (prod != null && qty != null && qty > 0) {
                                    onConfirm(prod.id, qty)
                                    Toast.makeText(context, "تمت إضافة $qty إلى رصيد ${prod.nameAr} بنجاح!", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "يرجى تحديد الصنف وإدخال كمية صحيحة", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5)),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("تأكيد التوريد", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MovementItemRow(
    movement: StockMovementEntity,
    currentLanguage: AppLanguage
) {
    val df = remember { SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault()) }
    val isIncoming = movement.type == MovementType.IN

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(if (isIncoming) Color(0xFFDCFCE7) else Color(0xFFFEE2E2)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isIncoming) "↓" else "↑",
                        fontWeight = FontWeight.Bold,
                        color = if (isIncoming) ProGreen else ProRed,
                        fontSize = 16.sp
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = movement.productName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${movement.notes} • ${df.format(Date(movement.timestamp))}",
                        fontSize = 10.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${if (isIncoming) "+" else "-"}${movement.quantity}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = if (isIncoming) ProGreen else ProRed
                )
                Text(
                    text = "رصيد: ${movement.newStock}",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
