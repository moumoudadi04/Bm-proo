package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PaymentMethod
import com.example.data.model.ProductEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings
import java.util.Locale

@Composable
fun NewInvoiceScreen(
    viewModel: MainViewModel,
    currentLanguage: AppLanguage
) {
    val products by viewModel.allProducts.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()
    val customerName by viewModel.customerName.collectAsState()
    val customerPhone by viewModel.customerPhone.collectAsState()
    val customerLocation by viewModel.customerLocation.collectAsState()
    val customerStoreAddress by viewModel.customerStoreAddress.collectAsState()
    val discount by viewModel.discountAmount.collectAsState()
    val paymentMethod by viewModel.selectedPaymentMethod.collectAsState()
    val context = androidx.compose.ui.platform.LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    val filteredProducts = remember(products, searchQuery) {
        if (searchQuery.isBlank()) products else {
            products.filter {
                it.nameAr.contains(searchQuery, ignoreCase = true) ||
                        it.barcode.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    val subtotal = cartItems.values.sumOf { (prod, qty) -> prod.sellPrice * qty }
    val discountedSubtotal = (subtotal - discount).coerceAtLeast(0.0)
    val taxAmount = discountedSubtotal * 0.15
    val totalAmount = discountedSubtotal + taxAmount

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Customer Info Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "بيانات الزبون ومحل التوصيل",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedTextField(
                            value = customerName,
                            onValueChange = { viewModel.setCustomerDetails(it, customerPhone, customerLocation, customerStoreAddress) },
                            placeholder = { Text(Strings.get("customer_name", currentLanguage)) },
                            singleLine = true,
                            modifier = Modifier.weight(1.2f)
                        )
                        OutlinedTextField(
                            value = customerPhone,
                            onValueChange = { viewModel.setCustomerDetails(customerName, it, customerLocation, customerStoreAddress) },
                            placeholder = { Text(Strings.get("customer_phone", currentLanguage)) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            singleLine = true,
                            modifier = Modifier.weight(0.8f)
                        )
                    }

                    // Store Location on Google Maps
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedTextField(
                            value = customerStoreAddress,
                            onValueChange = { viewModel.setCustomerDetails(customerName, customerPhone, customerLocation, it) },
                            placeholder = { Text("موقع أو عنوان محل الزبون على الخريطة") },
                            leadingIcon = {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = ProTeal
                                )
                            },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        if (customerStoreAddress.isNotBlank()) {
                            IconButton(
                                onClick = {
                                    val mapUri = android.net.Uri.parse("geo:0,0?q=${android.net.Uri.encode(customerStoreAddress)}")
                                    val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, mapUri)
                                    try {
                                        context.startActivity(intent)
                                    } catch (_: Exception) {
                                        val webIntent = android.content.Intent(
                                            android.content.Intent.ACTION_VIEW,
                                            android.net.Uri.parse("https://www.google.com/maps/search/?api=1&query=${android.net.Uri.encode(customerStoreAddress)}")
                                        )
                                        context.startActivity(webIntent)
                                    }
                                }
                            ) {
                                Icon(
                                    imageVector = Icons.Default.LocationOn,
                                    contentDescription = "Navigate to customer store",
                                    tint = com.example.ui.theme.ProBlue
                                )
                            }
                        }
                    }

                    // Payment Method selector
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        PaymentMethodChip(
                            label = Strings.get("pay_cash", currentLanguage),
                            selected = paymentMethod == PaymentMethod.CASH,
                            onClick = { viewModel.setPaymentMethod(PaymentMethod.CASH) }
                        )
                        PaymentMethodChip(
                            label = Strings.get("pay_card", currentLanguage),
                            selected = paymentMethod == PaymentMethod.CARD,
                            onClick = { viewModel.setPaymentMethod(PaymentMethod.CARD) }
                        )
                        PaymentMethodChip(
                            label = Strings.get("pay_debt", currentLanguage),
                            selected = paymentMethod == PaymentMethod.DEBT,
                            onClick = { viewModel.setPaymentMethod(PaymentMethod.DEBT) }
                        )
                    }
                }
            }
        }

        // Cart Items Section
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "أصناف الفاتورة (${cartItems.size})",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
                if (cartItems.isNotEmpty()) {
                    Text(
                        text = "تفريغ السلة",
                        color = Color.Red,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable { viewModel.clearCart() }
                    )
                }
            }
        }

        if (cartItems.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(20.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = Strings.get("cart_empty", currentLanguage) + " - اختر أصناف من القائمة أدناه",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        } else {
            items(cartItems.values.toList(), key = { it.first.id }) { (prod, qty) ->
                CartItemRow(
                    product = prod,
                    quantity = qty,
                    currentLanguage = currentLanguage,
                    onAdd = { viewModel.addToCart(prod, 1.0) },
                    onRemove = { viewModel.addToCart(prod, -1.0) },
                    onDelete = { viewModel.removeFromCart(prod.id) }
                )
            }
        }

        // Financial Totals Summary Card
        if (cartItems.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = Strings.get("subtotal", currentLanguage), fontSize = 13.sp)
                            Text(text = "${String.format(Locale.US, "%.2f", subtotal)} ${Strings.get("currency", currentLanguage)}", fontSize = 13.sp)
                        }

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = Strings.get("discount", currentLanguage), fontSize = 13.sp)
                            OutlinedTextField(
                                value = if (discount == 0.0) "" else discount.toString(),
                                onValueChange = { viewModel.setDiscount(it.toDoubleOrNull() ?: 0.0) },
                                placeholder = { Text("0.0") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                singleLine = true,
                                modifier = Modifier.width(100.dp)
                            )
                        }

                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = Strings.get("tax_15", currentLanguage), fontSize = 13.sp)
                            Text(text = "${String.format(Locale.US, "%.2f", taxAmount)} ${Strings.get("currency", currentLanguage)}", fontSize = 13.sp)
                        }

                        Divider(modifier = Modifier.padding(vertical = 4.dp))

                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = Strings.get("net_total", currentLanguage), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                text = "${String.format(Locale.US, "%.2f", totalAmount)} ${Strings.get("currency", currentLanguage)}",
                                fontWeight = FontWeight.Bold,
                                color = ProTeal,
                                fontSize = 17.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Button(
                            onClick = { viewModel.checkoutAndPrint() },
                            colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("checkout_print_btn")
                        ) {
                            Icon(Icons.Default.Print, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = Strings.get("complete_and_print", currentLanguage),
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }
                    }
                }
            }
        }

        // Quick Products Catalog Picker
        item {
            Text(
                text = "إضافة أصناف من المخزن",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("ابحث عن صنف لإضافته للفاتورة...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }

        items(filteredProducts.take(8)) { product ->
            CatalogItemPickRow(
                product = product,
                currentLanguage = currentLanguage,
                onPick = { viewModel.addToCart(product, 1.0) }
            )
        }
    }
}

@Composable
fun PaymentMethodChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    FilterChip(
        selected = selected,
        onClick = onClick,
        label = { Text(text = label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal) },
        leadingIcon = if (selected) {
            { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
        } else null
    )
}

@Composable
fun CartItemRow(
    product: ProductEntity,
    quantity: Double,
    currentLanguage: AppLanguage,
    onAdd: () -> Unit,
    onRemove: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = product.nameAr,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${String.format(Locale.US, "%.2f", product.sellPrice)} ${Strings.get("currency", currentLanguage)} / ${product.unit}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(18.dp))
                }
                Text(
                    text = "$quantity",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )
                IconButton(onClick = onAdd, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(18.dp))
                }
                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = Color.Red.copy(alpha = 0.7f), modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
fun CatalogItemPickRow(
    product: ProductEntity,
    currentLanguage: AppLanguage,
    onPick: () -> Unit
) {
    Surface(
        onClick = onPick,
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.padding(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = product.nameAr, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(text = "رصيد المخزن: ${product.currentStock} ${product.unit}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${String.format(Locale.US, "%.2f", product.sellPrice)} ${Strings.get("currency", currentLanguage)}",
                    fontWeight = FontWeight.Bold,
                    color = ProTeal,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(ProTeal.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add", tint = ProTeal, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
