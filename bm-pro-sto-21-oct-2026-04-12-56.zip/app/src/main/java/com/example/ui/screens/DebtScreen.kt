package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Paid
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.model.CustomerDebtEntity
import com.example.ui.MainViewModel
import com.example.ui.theme.ProAmber
import com.example.ui.theme.ProBlue
import com.example.ui.theme.ProGreen
import com.example.ui.theme.ProRed
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DebtScreen(
    viewModel: MainViewModel,
    currentLanguage: AppLanguage
) {
    val debts by viewModel.allDebts.collectAsState()
    val overdueDebts by viewModel.overdueDebts.collectAsState()
    val totalRemaining by viewModel.totalRemainingDebt.collectAsState()
    val context = LocalContext.current

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, OVERDUE, ACTIVE, SETTLED
    var showAddDialog by remember { mutableStateOf(false) }
    var payForDebt by remember { mutableStateOf<CustomerDebtEntity?>(null) }

    val filteredDebts = remember(debts, selectedFilter, searchQuery) {
        val byFilter = when (selectedFilter) {
            "OVERDUE" -> debts.filter { it.isOverdue }
            "ACTIVE" -> debts.filter { !it.isSettled && !it.isOverdue }
            "SETTLED" -> debts.filter { it.isSettled }
            else -> debts
        }
        if (searchQuery.isBlank()) {
            byFilter
        } else {
            byFilter.filter {
                it.customerName.contains(searchQuery, ignoreCase = true) ||
                        it.customerPhone.contains(searchQuery, ignoreCase = true) ||
                        it.storeAddress.contains(searchQuery, ignoreCase = true) ||
                        it.customerLocation.contains(searchQuery, ignoreCase = true)
            }
        }
    }

    val totalDebtAmount = totalRemaining ?: 0.0

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = ProAmber,
                contentColor = Color.White,
                modifier = Modifier.testTag("fab_add_debt")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Debt")
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Spacer(modifier = Modifier.height(4.dp))

            // Brand Header with Gold BM Emblem
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(14.dp)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.ic_bm_gold_logo),
                        contentDescription = "BM Gold Logo",
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "سجل ديون العملاء والتنقل لخرائط Google",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "ربط موقع محل الزبون والتنقل المباشر عبر Google Maps لشاحنات التوزيع",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // Search Bar for Customers and Store Locations
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("ابحث عن زبون بالاسم أو الهاتف أو موقع المحل...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Close, contentDescription = null)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_customer_debt_input")
            )

            // Summary Stats Cards
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = ProRed, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "متأخرين عن السداد", fontSize = 11.sp, color = ProRed, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            text = "${overdueDebts.size} عملاء",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = ProRed
                        )
                    }
                }

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.weight(1f)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MonetizationOn, contentDescription = null, tint = ProAmber, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "إجمالي الديون المعلقة", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            text = "${String.format(Locale.US, "%.0f", totalDebtAmount)} ر.س",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }

            // Filter Chips
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                FilterChip(
                    selected = selectedFilter == "ALL",
                    onClick = { selectedFilter = "ALL" },
                    label = { Text("الكل (${debts.size})") }
                )
                FilterChip(
                    selected = selectedFilter == "OVERDUE",
                    onClick = { selectedFilter = "OVERDUE" },
                    label = { Text("متأخر ⚠️ (${overdueDebts.size})") }
                )
                FilterChip(
                    selected = selectedFilter == "ACTIVE",
                    onClick = { selectedFilter = "ACTIVE" },
                    label = { Text("جارٍ السداد") }
                )
                FilterChip(
                    selected = selectedFilter == "SETTLED",
                    onClick = { selectedFilter = "SETTLED" },
                    label = { Text("مسدد ✅") }
                )
            }

            // Debts List
            if (filteredDebts.isEmpty()) {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            text = "لا توجد نتائج مطابقة لبحثك",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredDebts, key = { it.id }) { debt ->
                        CustomerDebtCard(
                            debt = debt,
                            currentLanguage = currentLanguage,
                            onNavigateToLocation = {
                                val query = when {
                                    debt.customerLocation.isNotBlank() -> debt.customerLocation
                                    debt.storeAddress.isNotBlank() -> debt.storeAddress
                                    else -> debt.customerName
                                }
                                val gmmIntentUri = if (query.startsWith("http://") || query.startsWith("https://")) {
                                    Uri.parse(query)
                                } else {
                                    Uri.parse("geo:0,0?q=${Uri.encode(query)}")
                                }
                                val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                                mapIntent.setPackage("com.google.android.apps.maps")
                                try {
                                    context.startActivity(mapIntent)
                                } catch (e: Exception) {
                                    // Fallback to browser or any map app
                                    val fallbackIntent = Intent(
                                        Intent.ACTION_VIEW,
                                        Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(query)}")
                                    )
                                    context.startActivity(fallbackIntent)
                                }
                            },
                            onPay = { payForDebt = debt },
                            onPrint = { viewModel.printDebtStatementReceipt(debt) },
                            onShareReminder = {
                                val df = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
                                val reminderText = """
                                    السلام عليكم ورحمة الله وبركاته،
                                    عزيزنا العميل: ${debt.customerName}
                                    
                                    نود تذكيركم بلطف بوجود رصيد آجل مستحق السداد لصالح شركة BM للمخازن والتوزيع:
                                    • المبلغ المتبقي: ${String.format(Locale.US, "%.2f", debt.remainingDebt)} ر.س
                                    • موعد الاستحقاق: ${df.format(Date(debt.dueDate))}
                                    • رقم الفاتورة: ${debt.invoiceNumber.ifBlank { "سند آجل" }}
                                    
                                    يرجى التكرم بسداد المبلغ المتبقي لتحديث حسابكم. شاكرين ومقدرين حسن تعاونكم الدائم.
                                    - إدارة الحسابات والتحصيل / BM ProSto
                                """.trimIndent()

                                val shareIntent = Intent().apply {
                                    action = Intent.ACTION_SEND
                                    putExtra(Intent.EXTRA_TEXT, reminderText)
                                    type = "text/plain"
                                }
                                context.startActivity(Intent.createChooser(shareIntent, "إرسال تذكير مطالبة بالسداد للعميل"))
                            },
                            onDelete = { viewModel.deleteDebt(debt.id) }
                        )
                    }
                }
            }
        }
    }

    // Add New Debt Dialog
    if (showAddDialog) {
        AddDebtDialog(
            currentLanguage = currentLanguage,
            onDismiss = { showAddDialog = false },
            onSave = {
                viewModel.saveDebt(it)
                showAddDialog = false
            }
        )
    }

    // Pay Debt Dialog
    payForDebt?.let { debt ->
        RecordPaymentDialog(
            debt = debt,
            currentLanguage = currentLanguage,
            onDismiss = { payForDebt = null },
            onConfirm = { amount ->
                viewModel.recordDebtPayment(debt.id, amount)
                payForDebt = null
            }
        )
    }
}

@Composable
fun CustomerDebtCard(
    debt: CustomerDebtEntity,
    currentLanguage: AppLanguage,
    onNavigateToLocation: () -> Unit,
    onPay: () -> Unit,
    onPrint: () -> Unit,
    onShareReminder: () -> Unit,
    onDelete: () -> Unit
) {
    val df = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
    val isOverdue = debt.isOverdue
    val isSettled = debt.isSettled

    val (badgeText, badgeBg, badgeTextColor) = when {
        isSettled -> Triple("مسدد بالكامل ✅", Color(0xFFDCFCE7), ProGreen)
        isOverdue -> Triple("متأخر عن السداد ⚠️", Color(0xFFFEE2E2), ProRed)
        else -> Triple("مستحق قريباً ⏳", Color(0xFFFEF3C7), ProAmber)
    }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isOverdue) Color(0xFFFFF7F7) else MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isOverdue) 2.dp else 1.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = debt.customerName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "هاتف: ${debt.customerPhone} • استحقاق: ${df.format(Date(debt.dueDate))}",
                        fontSize = 11.sp,
                        color = if (isOverdue) ProRed else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Surface(shape = RoundedCornerShape(8.dp), color = badgeBg) {
                    Text(
                        text = badgeText,
                        color = badgeTextColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Customer Location / Store on Google Maps
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                onClick = onNavigateToLocation,
                shape = RoundedCornerShape(8.dp),
                color = ProBlue.copy(alpha = 0.08f),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("customer_navigate_maps_btn")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Navigate on Google Maps",
                        tint = ProBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (debt.storeAddress.isNotBlank()) "المحل: ${debt.storeAddress}" else "التنقل لمحل الزبون عبر خرائط Google 🗺️",
                        fontSize = 11.sp,
                        color = ProBlue,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = "فتح الخريطة >",
                        fontSize = 11.sp,
                        color = ProBlue,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Debt Financials
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(text = "إجمالي الدين", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = "${String.format(Locale.US, "%.2f", debt.totalDebt)} ر.س", fontSize = 12.sp)
                }
                Column {
                    Text(text = "المسدد", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(text = "${String.format(Locale.US, "%.2f", debt.paidAmount)} ر.س", fontSize = 12.sp, color = ProGreen)
                }
                Column {
                    Text(text = "المتبقي بذمته", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        text = "${String.format(Locale.US, "%.2f", debt.remainingDebt)} ر.س",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = if (debt.remainingDebt > 0) ProRed else ProGreen
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Actions: WhatsApp Reminder, Payment, Print Statement, Delete
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (!isSettled) {
                        Button(
                            onClick = onShareReminder,
                            colors = ButtonDefaults.buttonColors(containerColor = ProAmber),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "مطالبة واتساب", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onPay,
                            colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Paid, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "سداد دفعة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Row {
                    IconButton(onClick = onPrint) {
                        Icon(Icons.Default.Print, contentDescription = "Print Statement", tint = ProBlue)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray)
                    }
                }
            }
        }
    }
}

@Composable
fun AddDebtDialog(
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (CustomerDebtEntity) -> Unit
) {
    val context = LocalContext.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var storeAddress by remember { mutableStateOf("") }
    var mapsLocation by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var daysToDue by remember { mutableStateOf("14") }
    var invoiceRef by remember { mutableStateOf("INV-${System.currentTimeMillis() % 100000}") }
    var notes by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "تسجيل زبون ودين جديد مع موقع الخريطة", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = null)
                    }
                }

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("اسم الزبون / صاحب المحل") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("رقم هاتف الزبون") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )

                // Google Maps Location Fields
                OutlinedTextField(
                    value = storeAddress,
                    onValueChange = { storeAddress = it },
                    label = { Text("عنوان أو اسم محل الزبون (مثلاً: سوبرماركت الهدى - الرياض)") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = ProTeal) },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = mapsLocation,
                    onValueChange = { mapsLocation = it },
                    label = { Text("رابط موقع Google Maps أو الإحداثيات (اختياري)") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = ProBlue) },
                    modifier = Modifier.fillMaxWidth()
                )

                // Quick presets for location
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                    listOf("الرياض - العليا", "جدة - البلد", "الدمام - السوق").forEach { preset ->
                        Surface(
                            onClick = { storeAddress = preset },
                            shape = RoundedCornerShape(6.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant
                        ) {
                            Text(
                                text = preset,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = amount,
                    onValueChange = { amount = it },
                    label = { Text("مبلغ الدين (ر.س)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = daysToDue,
                    onValueChange = { daysToDue = it },
                    label = { Text("أيام مهلة السداد (مثلاً 14 يوم)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("ملاحظات الفاتورة والتوصيل") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            val parsedAmount = amount.toDoubleOrNull() ?: 0.0
                            val days = daysToDue.toLongOrNull() ?: 14L
                            val due = System.currentTimeMillis() + (days * 86400000L)
                            val entity = CustomerDebtEntity(
                                customerName = name.ifBlank { "عميل آجل" },
                                customerPhone = phone.ifBlank { "0500000000" },
                                totalDebt = parsedAmount,
                                remainingDebt = parsedAmount,
                                dueDate = due,
                                invoiceNumber = invoiceRef,
                                customerLocation = mapsLocation,
                                storeAddress = storeAddress,
                                notes = notes
                            )
                            onSave(entity)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ProAmber),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("حفظ وربط الخريطة")
                    }

                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text(Strings.get("cancel", currentLanguage))
                    }
                }
            }
        }
    }
}

@Composable
fun RecordPaymentDialog(
    debt: CustomerDebtEntity,
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onConfirm: (Double) -> Unit
) {
    var paymentAmount by remember { mutableStateOf(debt.remainingDebt.toString()) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(text = "تسجيل سداد دفعة من الدين", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(text = "العميل: ${debt.customerName}", fontSize = 13.sp)
                Text(
                    text = "المبلغ المتبقي بذمته: ${debt.remainingDebt} ر.س",
                    fontWeight = FontWeight.Bold,
                    color = ProRed,
                    fontSize = 14.sp
                )

                OutlinedTextField(
                    value = paymentAmount,
                    onValueChange = { paymentAmount = it },
                    label = { Text("المبلغ المسدد الآن (ر.س)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = {
                            val amount = paymentAmount.toDoubleOrNull() ?: 0.0
                            if (amount > 0) onConfirm(amount)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("تأكيد السداد")
                    }
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text(Strings.get("cancel", currentLanguage))
                    }
                }
            }
        }
    }
}
