package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.ShiftState
import com.example.ui.theme.ProAmber
import com.example.ui.theme.ProGreen
import com.example.ui.theme.ProRed
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProStoTopBar(
    shiftState: ShiftState,
    currentLanguage: AppLanguage,
    lowStockCount: Int,
    onToggleStartupKey: () -> Unit,
    onToggleLanguage: () -> Unit,
    onOpenPrinter: () -> Unit,
    onOpenCloud: () -> Unit,
    onOpenSecurity: () -> Unit = {}
) {
    TopAppBar(
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            titleContentColor = MaterialTheme.colorScheme.onSurface
        ),
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                androidx.compose.foundation.Image(
                    painter = androidx.compose.ui.res.painterResource(id = com.example.R.drawable.ic_bm_truck_logo),
                    contentDescription = "BM Logo",
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape),
                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "BM ProSto",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = ProTeal.copy(alpha = 0.15f)
                        ) {
                            Text(
                                text = "مخازن وتوزيع",
                                fontSize = 10.sp,
                                color = ProTeal,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = if (shiftState.isActive) {
                            "● " + Strings.get("system_active", currentLanguage)
                        } else {
                            "○ " + Strings.get("system_idle", currentLanguage)
                        },
                        color = if (shiftState.isActive) ProGreen else ProRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        },
        actions = {
            // Master Startup Key (مفتاح بدء التشغيل)
            MasterStartupKeyButton(
                isActive = shiftState.isActive,
                currentLanguage = currentLanguage,
                onClick = onToggleStartupKey
            )

            // Printer Quick Access
            IconButton(
                onClick = onOpenPrinter,
                modifier = Modifier.testTag("top_bar_printer_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Print,
                    contentDescription = Strings.get("printer", currentLanguage),
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Cloud Sync Button
            IconButton(
                onClick = onOpenCloud,
                modifier = Modifier.testTag("top_bar_cloud_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.CloudDone,
                    contentDescription = Strings.get("cloud_database", currentLanguage),
                    tint = ProTeal
                )
            }

            // Language Toggle Button
            IconButton(
                onClick = onToggleLanguage,
                modifier = Modifier.testTag("top_bar_lang_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Language,
                    contentDescription = "Language",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Security & Master Key Settings
            IconButton(
                onClick = onOpenSecurity,
                modifier = Modifier.testTag("top_bar_security_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "Security",
                    tint = ProAmber
                )
            }
        }
    )
}

/**
 * Master Startup Key (مفتاح بدء التشغيل) with glowing active state indicator
 */
@Composable
fun MasterStartupKeyButton(
    isActive: Boolean,
    currentLanguage: AppLanguage,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(20.dp),
        color = if (isActive) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .testTag("master_startup_key")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Icon(
                imageVector = Icons.Default.PowerSettingsNew,
                contentDescription = Strings.get("startup_key", currentLanguage),
                tint = if (isActive) ProGreen else ProRed,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isActive) "تشغيل ON" else "إيقاف OFF",
                color = if (isActive) ProGreen else ProRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    subtitle: String = "",
    icon: ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    Card(
        modifier = modifier
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(accentColor.copy(alpha = 0.14f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                }

                if (subtitle.isNotEmpty()) {
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            Text(
                text = title,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun StockStatusBadge(
    currentStock: Double,
    minAlertStock: Double,
    currentLanguage: AppLanguage
) {
    val (label, bgColor, textColor) = when {
        currentStock <= 0 -> Triple(
            Strings.get("out_of_stock", currentLanguage),
            Color(0xFFFEE2E2),
            ProRed
        )
        currentStock <= minAlertStock -> Triple(
            Strings.get("low_stock", currentLanguage),
            Color(0xFFFEF3C7),
            ProAmber
        )
        else -> Triple(
            Strings.get("in_stock", currentLanguage),
            Color(0xFFDCFCE7),
            ProGreen
        )
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(textColor)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "$label (${currentStock.toInt()})",
                color = textColor,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
