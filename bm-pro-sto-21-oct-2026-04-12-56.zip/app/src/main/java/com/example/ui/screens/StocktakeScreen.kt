package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Pending
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.StocktakeItemEntity
import com.example.data.model.StocktakeSessionEntity
import com.example.data.model.StocktakeStatus
import com.example.ui.MainViewModel
import com.example.ui.theme.ProAmber
import com.example.ui.theme.ProBlue
import com.example.ui.theme.ProGreen
import com.example.ui.theme.ProRed
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.Strings
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StocktakeScreen(
    viewModel: MainViewModel,
    currentLanguage: AppLanguage
) {
    val sessions by viewModel.stocktakeSessions.collectAsState()
    val activeSessionId by viewModel.activeSessionId.collectAsState()
    val sessionItems by viewModel.sessionItems.collectAsState()

    var showNewSessionDialog by remember { mutableStateOf(false) }

    val activeSession = sessions.find { it.id == activeSessionId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header & Start Button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column {
                Text(
                    text = Strings.get("stocktake_title", currentLanguage),
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                )
                Text(
                    text = "جرد دقيق للمخزن وحساب الفروقات والتسويات",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Button(
                onClick = { showNewSessionDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("start_new_stocktake_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "جلسة جديدة", fontWeight = FontWeight.Bold)
            }
        }

        // Active Session View OR Sessions List
        if (activeSession != null) {
            ActiveStocktakeView(
                session = activeSession,
                items = sessionItems,
                currentLanguage = currentLanguage,
                onUpdateCount = { item, count -> viewModel.updateStocktakeCount(item, count) },
                onReconcile = { viewModel.reconcileAndApplyStocktake(activeSession.id) },
                onPrintReport = { viewModel.printStocktakeAuditReceipt(activeSession) },
                onBack = { viewModel.selectStocktakeSession(0) }
            )
        } else {
            // Sessions History
            if (sessions.isEmpty()) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.padding(32.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Assessment,
                            contentDescription = null,
                            tint = ProTeal,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "لا توجد جلسات جرد سابقة",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "ابدأ جلسة جرد دورية جديدة لحساب الفروقات الفعلية",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(sessions) { sess ->
                        StocktakeSessionCard(
                            session = sess,
                            currentLanguage = currentLanguage,
                            onClick = { viewModel.selectStocktakeSession(sess.id) }
                        )
                    }
                }
            }
        }
    }

    if (showNewSessionDialog) {
        NewStocktakeDialog(
            currentLanguage = currentLanguage,
            onDismiss = { showNewSessionDialog = false },
            onConfirm = { title ->
                viewModel.startNewStocktake(title)
                showNewSessionDialog = false
            }
        )
    }
}

@Composable
fun ActiveStocktakeView(
    session: StocktakeSessionEntity,
    items: List<StocktakeItemEntity>,
    currentLanguage: AppLanguage,
    onUpdateCount: (StocktakeItemEntity, Double) -> Unit,
    onReconcile: () -> Unit,
    onPrintReport: () -> Unit,
    onBack: () -> Unit
) {
    val discrepancies = items.count { it.variance != 0.0 }
    val totalVarianceValue = items.sumOf { it.varianceValue }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Session Status Banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(text = session.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            text = "الأصناف: ${items.size} • الفروقات: $discrepancies",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = onPrintReport,
                        colors = ButtonDefaults.buttonColors(containerColor = ProBlue.copy(alpha = 0.15f), contentColor = ProBlue)
                    ) {
                        Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "طباعة محضر الجرد", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                if (session.status == StocktakeStatus.IN_PROGRESS) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = onReconcile,
                        colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().testTag("reconcile_apply_btn")
                    ) {
                        Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = Strings.get("reconcile_and_apply", currentLanguage), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Items List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items, key = { it.id }) { item ->
                StocktakeItemAuditRow(
                    item = item,
                    currentLanguage = currentLanguage,
                    onUpdateCount = { onUpdateCount(item, it) }
                )
            }
        }
    }
}

@Composable
fun StocktakeItemAuditRow(
    item: StocktakeItemEntity,
    currentLanguage: AppLanguage,
    onUpdateCount: (Double) -> Unit
) {
    val (statusLabel, statusColor) = when {
        item.variance < 0 -> Pair("عجز (${item.variance.toInt()})", ProRed)
        item.variance > 0 -> Pair("زيادة (+${item.variance.toInt()})", ProBlue)
        else -> Pair("مطابق", ProGreen)
    }

    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = item.productName,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.weight(1f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = statusLabel,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "المسجل: ${item.expectedStock}",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Actual Count Stepper
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "الفعلي:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.width(6.dp))
                    IconButton(
                        onClick = { onUpdateCount((item.actualCount - 1.0).coerceAtLeast(0.0)) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "${item.actualCount}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = ProTeal,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    IconButton(
                        onClick = { onUpdateCount(item.actualCount + 1.0) },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun StocktakeSessionCard(
    session: StocktakeSessionEntity,
    currentLanguage: AppLanguage,
    onClick: () -> Unit
) {
    val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())

    Card(
        onClick = onClick,
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(if (session.status == StocktakeStatus.COMPLETED) ProGreen.copy(alpha = 0.15f) else ProAmber.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (session.status == StocktakeStatus.COMPLETED) Icons.Default.CheckCircle else Icons.Default.Pending,
                    contentDescription = null,
                    tint = if (session.status == StocktakeStatus.COMPLETED) ProGreen else ProAmber,
                    modifier = Modifier.size(22.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(text = session.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    text = "${dateFormat.format(Date(session.startedAt))} • ${if (session.status == StocktakeStatus.COMPLETED) "مكتمل ومعتمد" else "قيد التنفيذ"}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = "فتح >",
                fontWeight = FontWeight.Bold,
                color = ProTeal,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun NewStocktakeDialog(
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onConfirm: (String) -> Unit
) {
    var title by remember {
        mutableStateOf("جرد مخزني - " + SimpleDateFormat("yyyy/MM/dd", Locale.getDefault()).format(Date()))
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.padding(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = Strings.get("start_new_stocktake", currentLanguage), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    text = "سيتم إنشاء جلسة جرد جديدة وتثبيت الأرصدة الدفترية لمقارنتها بالعد الفعلي",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(Strings.get("session_name", currentLanguage)) },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { onConfirm(title) },
                        colors = ButtonDefaults.buttonColors(containerColor = ProTeal),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("بدء الجرد الآن")
                    }
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) {
                        Text(Strings.get("cancel", currentLanguage))
                    }
                }
            }
        }
    }
}
