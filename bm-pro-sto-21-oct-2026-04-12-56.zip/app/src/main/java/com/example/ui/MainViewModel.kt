package com.example.ui

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.ProStoDatabase
import com.example.data.model.InvoiceEntity
import com.example.data.model.InvoiceItemEntity
import com.example.data.model.PaymentMethod
import com.example.data.model.ProductEntity
import com.example.data.model.StockMovementEntity
import com.example.data.model.StocktakeItemEntity
import com.example.data.model.StocktakeSessionEntity
import com.example.data.repository.InventoryRepository
import com.example.printer.PrinterConfig
import com.example.printer.ThermalPrinterManager
import com.example.util.AppLanguage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class Screen {
    DASHBOARD,
    PRODUCTS,
    NEW_INVOICE,
    STOCKTAKE,
    SHORTAGES,
    DEBTS,
    REPORTS,
    PRINTER_SETTINGS,
    CLOUD_SYNC
}

data class ReceiptDialogState(
    val isOpen: Boolean = false,
    val invoice: InvoiceEntity? = null,
    val items: List<InvoiceItemEntity> = emptyList(),
    val rawTextReceipt: String = ""
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = ProStoDatabase.getDatabase(application)
    val repository = InventoryRepository(
        productDao = db.productDao(),
        movementDao = db.movementDao(),
        invoiceDao = db.invoiceDao(),
        stocktakeDao = db.stocktakeDao(),
        debtDao = db.debtDao()
    )

    val securityManager = com.example.util.SecurityManager(application)
    val isActivated = securityManager.isActivatedState

    // Security Settings Dialog
    private val _showSecuritySettingsDialog = MutableStateFlow(false)
    val showSecuritySettingsDialog: StateFlow<Boolean> = _showSecuritySettingsDialog.asStateFlow()

    fun openSecuritySettings() {
        _showSecuritySettingsDialog.value = true
    }

    fun closeSecuritySettings() {
        _showSecuritySettingsDialog.value = false
    }

    // Current navigation screen
    private val _currentScreen = MutableStateFlow(Screen.DASHBOARD)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    // Language
    val currentLanguage = repository.currentLanguage
    fun toggleLanguage() {
        val next = if (currentLanguage.value == AppLanguage.ARABIC) AppLanguage.ENGLISH else AppLanguage.ARABIC
        repository.setLanguage(next)
    }

    // Master Startup Switch (مفتاح بدء التشغيل)
    val shiftState = repository.shiftState
    fun toggleStartupKey() {
        repository.toggleMasterStartupKey()
        val isActiveNow = !shiftState.value.isActive
        val msg = if (isActiveNow) "تم تشغيل وردية المخزن بنجاح!" else "تم إيقاف تشغيل وردية المخزن وإغلاق اليومية."
        Toast.makeText(getApplication(), msg, Toast.LENGTH_SHORT).show()
    }

    // Search and filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Products
    val allProducts = repository.allProducts.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val lowStockProducts = repository.lowStockProducts.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val filteredProducts = combine(allProducts, searchQuery) { products, query ->
        if (query.isBlank()) {
            products
        } else {
            products.filter {
                it.nameAr.contains(query, ignoreCase = true) ||
                        it.nameEn.contains(query, ignoreCase = true) ||
                        it.barcode.contains(query, ignoreCase = true) ||
                        it.category.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalProductCount = repository.totalProductCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val totalCostValue = repository.totalCostValue.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)
    val totalSellValue = repository.totalSellValue.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val recentMovements = repository.recentMovements.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allInvoices = repository.allInvoices.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Product Add/Edit Dialog State
    private val _editingProduct = MutableStateFlow<ProductEntity?>(null)
    val editingProduct: StateFlow<ProductEntity?> = _editingProduct.asStateFlow()

    private val _isProductDialogOpen = MutableStateFlow(false)
    val isProductDialogOpen: StateFlow<Boolean> = _isProductDialogOpen.asStateFlow()

    fun openAddProductDialog(product: ProductEntity? = null) {
        _editingProduct.value = product
        _isProductDialogOpen.value = true
    }

    fun closeProductDialog() {
        _editingProduct.value = null
        _isProductDialogOpen.value = false
    }

    fun saveProduct(product: ProductEntity) {
        viewModelScope.launch {
            repository.saveProduct(product)
            closeProductDialog()
            Toast.makeText(getApplication(), "تم حفظ الصنف بنجاح", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteProduct(productId: Long) {
        viewModelScope.launch {
            repository.deleteProduct(productId)
            Toast.makeText(getApplication(), "تم حذف الصنف", Toast.LENGTH_SHORT).show()
        }
    }

    fun quickRestock(productId: Long, qty: Double) {
        viewModelScope.launch {
            repository.quickRestock(productId, qty)
            Toast.makeText(getApplication(), "تم إضافة $qty للرصيد بنجاح", Toast.LENGTH_SHORT).show()
        }
    }

    // POS & New Invoice Cart
    private val _cartItems = MutableStateFlow<Map<Long, Pair<ProductEntity, Double>>>(emptyMap())
    val cartItems: StateFlow<Map<Long, Pair<ProductEntity, Double>>> = _cartItems.asStateFlow()

    private val _customerName = MutableStateFlow("")
    val customerName: StateFlow<String> = _customerName.asStateFlow()

    private val _customerPhone = MutableStateFlow("")
    val customerPhone: StateFlow<String> = _customerPhone.asStateFlow()

    private val _discountAmount = MutableStateFlow(0.0)
    val discountAmount: StateFlow<Double> = _discountAmount.asStateFlow()

    private val _selectedPaymentMethod = MutableStateFlow(PaymentMethod.CASH)
    val selectedPaymentMethod: StateFlow<PaymentMethod> = _selectedPaymentMethod.asStateFlow()

    fun addToCart(product: ProductEntity, qtyDelta: Double = 1.0) {
        val current = _cartItems.value.toMutableMap()
        val existing = current[product.id]
        val currentQty = existing?.second ?: 0.0
        val newQty = (currentQty + qtyDelta).coerceAtLeast(0.0)
        if (newQty <= 0.0) {
            current.remove(product.id)
        } else {
            current[product.id] = Pair(product, newQty)
        }
        _cartItems.value = current
    }

    fun removeFromCart(productId: Long) {
        val current = _cartItems.value.toMutableMap()
        current.remove(productId)
        _cartItems.value = current
    }

    fun clearCart() {
        _cartItems.value = emptyMap()
        _customerName.value = ""
        _customerPhone.value = ""
        _discountAmount.value = 0.0
    }

    private val _customerLocation = MutableStateFlow("")
    val customerLocation: StateFlow<String> = _customerLocation.asStateFlow()

    private val _customerStoreAddress = MutableStateFlow("")
    val customerStoreAddress: StateFlow<String> = _customerStoreAddress.asStateFlow()

    fun setCustomerDetails(name: String, phone: String, location: String = "", address: String = "") {
        _customerName.value = name
        _customerPhone.value = phone
        _customerLocation.value = location
        _customerStoreAddress.value = address
    }

    fun setDiscount(discount: Double) {
        _discountAmount.value = discount
    }

    fun setPaymentMethod(method: PaymentMethod) {
        _selectedPaymentMethod.value = method
    }

    // Receipt Dialog State
    private val _receiptDialogState = MutableStateFlow(ReceiptDialogState())
    val receiptDialogState: StateFlow<ReceiptDialogState> = _receiptDialogState.asStateFlow()

    fun closeReceiptDialog() {
        _receiptDialogState.value = ReceiptDialogState(isOpen = false)
    }

    fun checkoutAndPrint() {
        val itemsList = _cartItems.value.values.toList()
        if (itemsList.isEmpty()) {
            Toast.makeText(getApplication(), "السلة فارغة!", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            val (savedInvoice, invoiceItems) = repository.createInvoice(
                partyName = _customerName.value,
                partyPhone = _customerPhone.value,
                discount = _discountAmount.value,
                taxRate = 0.15,
                paymentMethod = _selectedPaymentMethod.value,
                cartItems = itemsList,
                customerLocation = _customerLocation.value,
                storeAddress = _customerStoreAddress.value
            )

            val rawText = ThermalPrinterManager.buildInvoiceTextReceipt(
                savedInvoice,
                invoiceItems,
                printerConfig.value
            )

            _receiptDialogState.value = ReceiptDialogState(
                isOpen = true,
                invoice = savedInvoice,
                items = invoiceItems,
                rawTextReceipt = rawText
            )

            clearCart()
            Toast.makeText(getApplication(), "تم إنشاء الفاتورة وحفظها بنجاح!", Toast.LENGTH_SHORT).show()
        }
    }

    fun viewInvoiceReceipt(invoice: InvoiceEntity) {
        viewModelScope.launch {
            val items = repository.getInvoiceItems(invoice.id)
            val rawText = ThermalPrinterManager.buildInvoiceTextReceipt(
                invoice,
                items,
                printerConfig.value
            )
            _receiptDialogState.value = ReceiptDialogState(
                isOpen = true,
                invoice = invoice,
                items = items,
                rawTextReceipt = rawText
            )
        }
    }

    // Thermal Printer Settings
    val printerConfig = repository.printerConfig
    fun updatePrinterConfig(config: PrinterConfig) {
        repository.updatePrinterConfig(config)
        Toast.makeText(getApplication(), "تم تحديث إعدادات الطابعة", Toast.LENGTH_SHORT).show()
    }

    fun triggerTestPrint() {
        val testText = ThermalPrinterManager.buildTestReceipt(printerConfig.value)
        _receiptDialogState.value = ReceiptDialogState(
            isOpen = true,
            invoice = null,
            items = emptyList(),
            rawTextReceipt = testText
        )
    }

    // Stocktake (الجرد الدقيق)
    val stocktakeSessions = repository.allStocktakeSessions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeSessionId = MutableStateFlow<Long?>(null)
    val activeSessionId: StateFlow<Long?> = _activeSessionId.asStateFlow()

    private val _sessionItems = MutableStateFlow<List<StocktakeItemEntity>>(emptyList())
    val sessionItems: StateFlow<List<StocktakeItemEntity>> = _sessionItems.asStateFlow()

    fun selectStocktakeSession(sessionId: Long) {
        _activeSessionId.value = sessionId
        viewModelScope.launch {
            repository.getItemsForSession(sessionId).collect { items ->
                _sessionItems.value = items
            }
        }
    }

    fun startNewStocktake(title: String) {
        viewModelScope.launch {
            val sessionId = repository.startNewStocktakeSession(title, allProducts.value)
            selectStocktakeSession(sessionId)
            Toast.makeText(getApplication(), "تم بدء جلسة جرد جديدة بنجاح", Toast.LENGTH_SHORT).show()
        }
    }

    fun updateStocktakeCount(item: StocktakeItemEntity, newCount: Double) {
        viewModelScope.launch {
            repository.updateStocktakeItemCount(item, newCount)
        }
    }

    fun reconcileAndApplyStocktake(sessionId: Long) {
        viewModelScope.launch {
            repository.reconcileAndCloseStocktake(sessionId)
            Toast.makeText(getApplication(), "تم اعتماد الجرد وتسوية المخزون بالكامل!", Toast.LENGTH_LONG).show()
        }
    }

    fun printStocktakeAuditReceipt(session: StocktakeSessionEntity) {
        viewModelScope.launch {
            val items = _sessionItems.value
            val text = ThermalPrinterManager.buildStocktakeReceipt(session, items, printerConfig.value)
            _receiptDialogState.value = ReceiptDialogState(
                isOpen = true,
                invoice = null,
                items = emptyList(),
                rawTextReceipt = text
            )
        }
    }

    // Cloud Sync
    val lastCloudSyncTimestamp = repository.lastCloudSyncTimestamp
    val isCloudSyncing = repository.isCloudSyncing

    fun triggerCloudSyncNow() {
        viewModelScope.launch {
            repository.triggerCloudSync()
            Toast.makeText(getApplication(), "تمت المزامنة السحابية بنجاح ☁️", Toast.LENGTH_SHORT).show()
        }
    }

    fun exportCloudBackup() {
        viewModelScope.launch {
            val jsonStr = repository.exportCloudBackupJson(allProducts.value, allInvoices.value)
            Toast.makeText(getApplication(), "تم تجهيز النسخة الاحتياطية السحابية (${allProducts.value.size} أصناف)", Toast.LENGTH_LONG).show()
        }
    }

    // Customer Debts & Overdue Alerts (الديون والتنبيهات)
    val allDebts = repository.allDebts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val overdueDebts = repository.overdueDebts.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val totalRemainingDebt = repository.totalRemainingDebt.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    fun recordDebtPayment(debtId: Long, paymentAmount: Double) {
        viewModelScope.launch {
            repository.recordDebtPayment(debtId, paymentAmount)
            Toast.makeText(getApplication(), "تم تسجيل سداد الدفعة بنجاح بقيمة $paymentAmount", Toast.LENGTH_SHORT).show()
        }
    }

    fun saveDebt(debt: com.example.data.model.CustomerDebtEntity) {
        viewModelScope.launch {
            repository.saveDebt(debt)
            Toast.makeText(getApplication(), "تم حفظ الدين بنجاح", Toast.LENGTH_SHORT).show()
        }
    }

    fun deleteDebt(debtId: Long) {
        viewModelScope.launch {
            repository.deleteDebt(debtId)
            Toast.makeText(getApplication(), "تم حذف سجل الدين", Toast.LENGTH_SHORT).show()
        }
    }

    fun printDebtStatementReceipt(debt: com.example.data.model.CustomerDebtEntity) {
        val width = printerConfig.value.paperWidth.charsPerLine
        val div = "-".repeat(width)
        val sb = StringBuilder()
        sb.append("   إيصال وكشف حساب دين عميل   \n")
        sb.append("   ${printerConfig.value.storeName}\n")
        sb.append(div).append("\n")
        sb.append("العميل: ${debt.customerName}\n")
        sb.append("الهاتف: ${debt.customerPhone}\n")
        sb.append("رقم الفاتورة: ${debt.invoiceNumber.ifBlank { "سند دين" }}\n")
        sb.append("إجمالي الدين: ${debt.totalDebt} ${printerConfig.value.currencySymbol}\n")
        sb.append("المدفوع: ${debt.paidAmount} ${printerConfig.value.currencySymbol}\n")
        sb.append("المتبقي بذمته: ${debt.remainingDebt} ${printerConfig.value.currencySymbol}\n")
        val df = java.text.SimpleDateFormat("yyyy/MM/dd", java.util.Locale.getDefault())
        sb.append("تاريخ الاستحقاق: ${df.format(java.util.Date(debt.dueDate))}\n")
        if (debt.isOverdue) {
            sb.append("الحالة: متأخر عن السداد (مطالبة فورية) ⚠️\n")
        } else if (debt.isSettled) {
            sb.append("الحالة: تم السداد بالكامل وجزيل الشكر ✅\n")
        } else {
            sb.append("الحالة: جارٍ السداد\n")
        }
        sb.append(div).append("\n")
        sb.append("توقيع المستلم: _____________\n\n\n")

        _receiptDialogState.value = ReceiptDialogState(
            isOpen = true,
            invoice = null,
            items = emptyList(),
            rawTextReceipt = sb.toString()
        )
    }
}

