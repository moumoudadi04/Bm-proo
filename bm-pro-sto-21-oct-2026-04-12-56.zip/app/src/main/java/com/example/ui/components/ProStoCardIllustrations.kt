package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ProAmber
import com.example.ui.theme.ProGreen
import com.example.ui.theme.ProRed
import com.example.ui.theme.ProTeal

/**
 * 1. المنتجات: كراتين بضاعة ومخزن موضوعة على طبلية خشبية (مثل الصورة تماماً)
 */
@Composable
fun ProductsIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Pallet wood slats at bottom
            val woodColor = Color(0xFFC49A6C)
            val woodDark = Color(0xFF8D6236)
            drawRoundRect(
                color = woodDark,
                topLeft = Offset(w * 0.08f, h * 0.78f),
                size = Size(w * 0.84f, h * 0.12f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            // Pallet supports
            drawRect(woodDark, Offset(w * 0.12f, h * 0.86f), Size(w * 0.14f, h * 0.08f))
            drawRect(woodDark, Offset(w * 0.43f, h * 0.86f), Size(w * 0.14f, h * 0.08f))
            drawRect(woodDark, Offset(w * 0.74f, h * 0.86f), Size(w * 0.14f, h * 0.08f))

            // Box 1 (Left lower box - Orange/Brown cardboard)
            val boxBase = Color(0xFFE27D60)
            val boxDark = Color(0xFFC05C46)
            val tapeColor = Color(0xFFE8A87C)

            drawRoundRect(
                color = boxBase,
                topLeft = Offset(w * 0.12f, h * 0.38f),
                size = Size(w * 0.38f, h * 0.40f),
                cornerRadius = CornerRadius(6f, 6f)
            )
            // Tape
            drawRect(tapeColor, Offset(w * 0.28f, h * 0.38f), Size(w * 0.06f, h * 0.40f))

            // Box 2 (Right lower box)
            drawRoundRect(
                color = boxDark,
                topLeft = Offset(w * 0.48f, h * 0.32f),
                size = Size(w * 0.40f, h * 0.46f),
                cornerRadius = CornerRadius(6f, 6f)
            )
            drawRect(tapeColor, Offset(w * 0.65f, h * 0.32f), Size(w * 0.06f, h * 0.46f))

            // Box 3 (Top box)
            val boxTop = Color(0xFFE89870)
            drawRoundRect(
                color = boxTop,
                topLeft = Offset(w * 0.22f, h * 0.12f),
                size = Size(w * 0.44f, h * 0.30f),
                cornerRadius = CornerRadius(6f, 6f)
            )
            drawRect(tapeColor, Offset(w * 0.41f, h * 0.12f), Size(w * 0.06f, h * 0.30f))

            // Shipping label on top box
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(w * 0.26f, h * 0.18f),
                size = Size(w * 0.12f, h * 0.14f),
                cornerRadius = CornerRadius(2f, 2f)
            )
        }
    }
}

/**
 * 2. الأصناف: سلة تسوق زرقاء شبكية ممتلئة بالسلع (مثل الصورة تماماً)
 */
@Composable
fun CategoriesIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Items inside basket
            drawRoundRect(
                color = Color(0xFFD7CCC8),
                topLeft = Offset(w * 0.24f, h * 0.14f),
                size = Size(w * 0.24f, h * 0.30f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            drawRoundRect(
                color = Color(0xFFFFCC80),
                topLeft = Offset(w * 0.46f, h * 0.18f),
                size = Size(w * 0.28f, h * 0.28f),
                cornerRadius = CornerRadius(4f, 4f)
            )

            // Basket body (Blue plastic crate)
            val basketBlue = Color(0xFF1E88E5)
            val basketDark = Color(0xFF1565C0)
            val rimColor = Color(0xFF90CAF9)

            val path = Path().apply {
                moveTo(w * 0.14f, h * 0.38f)
                lineTo(w * 0.86f, h * 0.38f)
                lineTo(w * 0.76f, h * 0.88f)
                lineTo(w * 0.24f, h * 0.88f)
                close()
            }
            drawPath(path, basketBlue)

            // Top rim
            drawRoundRect(
                color = rimColor,
                topLeft = Offset(w * 0.10f, h * 0.34f),
                size = Size(w * 0.80f, h * 0.08f),
                cornerRadius = CornerRadius(6f, 6f)
            )

            // Grid holes on basket
            val gridColor = Color(0xFF0D47A1)
            for (row in 0..2) {
                val y = h * (0.48f + row * 0.12f)
                for (col in 0..3) {
                    val x = w * (0.28f + col * 0.12f - row * 0.02f)
                    drawRoundRect(
                        color = gridColor,
                        topLeft = Offset(x, y),
                        size = Size(w * 0.08f, h * 0.07f),
                        cornerRadius = CornerRadius(2f, 2f)
                    )
                }
            }

            // Handle
            drawRoundRect(
                color = Color(0xFFB0BEC5),
                topLeft = Offset(w * 0.32f, h * 0.08f),
                size = Size(w * 0.36f, h * 0.28f),
                cornerRadius = CornerRadius(8f, 8f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f)
            )
        }
    }
}

/**
 * 3. المبيعات: فواتير بيع وإيصالات ورق حراري ملونة (مثل الصورة تماماً)
 */
@Composable
fun SalesIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Yellow receipt in background
            drawRoundRect(
                color = Color(0xFFFFF59D),
                topLeft = Offset(w * 0.16f, h * 0.16f),
                size = Size(w * 0.36f, h * 0.68f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            // Blue receipt
            drawRoundRect(
                color = Color(0xFF90CAF9),
                topLeft = Offset(w * 0.32f, h * 0.12f),
                size = Size(w * 0.38f, h * 0.72f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            // White main receipt in front
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(w * 0.22f, h * 0.22f),
                size = Size(w * 0.54f, h * 0.64f),
                cornerRadius = CornerRadius(4f, 4f)
            )

            // Red header on main receipt
            drawRect(
                color = Color(0xFFEF5350),
                topLeft = Offset(w * 0.22f, h * 0.22f),
                size = Size(w * 0.54f, h * 0.10f)
            )

            // Text / barcode lines on receipt
            val lineColor = Color(0xFF9E9E9E)
            drawLine(lineColor, Offset(w * 0.28f, h * 0.40f), Offset(w * 0.70f, h * 0.40f), strokeWidth = 5f)
            drawLine(lineColor, Offset(w * 0.28f, h * 0.48f), Offset(w * 0.65f, h * 0.48f), strokeWidth = 5f)
            drawLine(lineColor, Offset(w * 0.28f, h * 0.56f), Offset(w * 0.58f, h * 0.56f), strokeWidth = 5f)

            // Total price line (Green)
            drawLine(Color(0xFF2E7D32), Offset(w * 0.28f, h * 0.68f), Offset(w * 0.70f, h * 0.68f), strokeWidth = 7f)

            // Barcode bottom lines
            for (i in 0..7) {
                val bx = w * (0.30f + i * 0.05f)
                val bw = if (i % 2 == 0) 3f else 6f
                drawLine(Color.Black, Offset(bx, h * 0.76f), Offset(bx, h * 0.82f), strokeWidth = bw)
            }
        }
    }
}

/**
 * 4. المشتريات: ملف فواتير الشراء والتوريد مع عدسة/مكبر (مثل الصورة تماماً)
 */
@Composable
fun PurchasesIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Ledger base
            drawRoundRect(
                color = Color(0xFFE0E0E0),
                topLeft = Offset(w * 0.18f, h * 0.14f),
                size = Size(w * 0.64f, h * 0.72f),
                cornerRadius = CornerRadius(6f, 6f)
            )

            // Cyan document body
            drawRoundRect(
                color = Color(0xFFE0F7FA),
                topLeft = Offset(w * 0.22f, h * 0.18f),
                size = Size(w * 0.56f, h * 0.64f),
                cornerRadius = CornerRadius(4f, 4f)
            )

            // Header bar (Blue)
            drawRect(
                color = Color(0xFF00838F),
                topLeft = Offset(w * 0.22f, h * 0.18f),
                size = Size(w * 0.56f, h * 0.10f)
            )

            // Lines
            val lineC = Color(0xFF006064)
            drawLine(lineC, Offset(w * 0.28f, h * 0.36f), Offset(w * 0.72f, h * 0.36f), strokeWidth = 5f)
            drawLine(lineC, Offset(w * 0.28f, h * 0.44f), Offset(w * 0.72f, h * 0.44f), strokeWidth = 5f)
            drawLine(lineC, Offset(w * 0.28f, h * 0.52f), Offset(w * 0.60f, h * 0.52f), strokeWidth = 5f)
            drawLine(lineC, Offset(w * 0.28f, h * 0.60f), Offset(w * 0.68f, h * 0.60f), strokeWidth = 5f)

            // Red delivery/inward pointer cone
            val conePath = Path().apply {
                moveTo(w * 0.55f, h * 0.46f)
                lineTo(w * 0.88f, h * 0.36f)
                lineTo(w * 0.88f, h * 0.56f)
                close()
            }
            drawPath(conePath, Color(0xFFD32F2F))
        }
    }
}

/**
 * 5. الديون والزبائن: ركن الديون مع موقع الزبون على خرائط Google ونقود (المطلوبة بالطلب)
 */
@Composable
fun DebtsIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Ledger card
            drawRoundRect(
                color = Color(0xFFFFF8E1),
                topLeft = Offset(w * 0.14f, h * 0.20f),
                size = Size(w * 0.72f, h * 0.64f),
                cornerRadius = CornerRadius(8f, 8f)
            )
            // Border
            drawRoundRect(
                color = Color(0xFFFFB300),
                topLeft = Offset(w * 0.14f, h * 0.20f),
                size = Size(w * 0.72f, h * 0.64f),
                cornerRadius = CornerRadius(8f, 8f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 4f)
            )

            // Gold Coin Stack
            val coinGold = Color(0xFFFFB300)
            val coinDark = Color(0xFFF57F17)
            for (i in 0..2) {
                val cy = h * (0.64f - i * 0.08f)
                drawOval(coinDark, Offset(w * 0.24f, cy), Size(w * 0.26f, h * 0.12f))
                drawOval(coinGold, Offset(w * 0.24f, cy - 4f), Size(w * 0.26f, h * 0.11f))
            }

            // Google Maps GPS Location Pin 📍
            val pinRed = Color(0xFFEA4335)
            drawCircle(pinRed, radius = w * 0.14f, center = Offset(w * 0.66f, h * 0.38f))
            drawCircle(Color.White, radius = w * 0.06f, center = Offset(w * 0.66f, h * 0.38f))

            val pinTriangle = Path().apply {
                moveTo(w * 0.54f, h * 0.42f)
                lineTo(w * 0.78f, h * 0.42f)
                lineTo(w * 0.66f, h * 0.62f)
                close()
            }
            drawPath(pinTriangle, pinRed)
        }
    }
}

/**
 * 6. الصندوق: آلة وصندوق النقدية الأزرق الكلاسيكي (مثل الصورة تماماً)
 */
@Composable
fun CashboxIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // 3D Isometric Cash Register / Safe Box in Blue
            val topColor = Color(0xFF42A5F5)
            val leftColor = Color(0xFF1E88E5)
            val rightColor = Color(0xFF0D47A1)

            // Top face
            val topPath = Path().apply {
                moveTo(w * 0.50f, h * 0.14f)
                lineTo(w * 0.82f, h * 0.30f)
                lineTo(w * 0.50f, h * 0.46f)
                lineTo(w * 0.18f, h * 0.30f)
                close()
            }
            drawPath(topPath, topColor)

            // Left face
            val leftPath = Path().apply {
                moveTo(w * 0.18f, h * 0.30f)
                lineTo(w * 0.50f, h * 0.46f)
                lineTo(w * 0.50f, h * 0.84f)
                lineTo(w * 0.18f, h * 0.68f)
                close()
            }
            drawPath(leftPath, leftColor)

            // Right face
            val rightPath = Path().apply {
                moveTo(w * 0.50f, h * 0.46f)
                lineTo(w * 0.82f, h * 0.30f)
                lineTo(w * 0.82f, h * 0.68f)
                lineTo(w * 0.50f, h * 0.84f)
                close()
            }
            drawPath(rightPath, rightColor)

            // Vents / key slots on front face
            for (i in 0..2) {
                val vy = h * (0.52f + i * 0.08f)
                drawLine(Color.White, Offset(w * 0.24f, vy), Offset(w * 0.42f, vy + h * 0.07f), strokeWidth = 3f)
                drawLine(Color.White, Offset(w * 0.58f, vy + h * 0.07f), Offset(w * 0.76f, vy), strokeWidth = 3f)
            }
        }
    }
}

/**
 * 7. المصروفات: محفظة جلدية بنية تخرج منها النقود والعملات (مثل الصورة تماماً)
 */
@Composable
fun ExpensesIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Banknotes popping out from top (Green paper money)
            val note1 = Color(0xFFA5D6A7)
            val note2 = Color(0xFFC8E6C9)

            val p1 = Path().apply {
                moveTo(w * 0.28f, h * 0.16f)
                lineTo(w * 0.50f, h * 0.30f)
                lineTo(w * 0.40f, h * 0.48f)
                lineTo(w * 0.18f, h * 0.34f)
                close()
            }
            drawPath(p1, note1)

            val p2 = Path().apply {
                moveTo(w * 0.44f, h * 0.14f)
                lineTo(w * 0.68f, h * 0.30f)
                lineTo(w * 0.58f, h * 0.48f)
                lineTo(w * 0.34f, h * 0.34f)
                close()
            }
            drawPath(p2, note2)

            // Wallet Body (Brown leather)
            val leatherMain = Color(0xFF6D4C41)
            val leatherDark = Color(0xFF4E342E)
            val claspColor = Color(0xFFFFB300)

            drawRoundRect(
                color = leatherMain,
                topLeft = Offset(w * 0.14f, h * 0.34f),
                size = Size(w * 0.72f, h * 0.54f),
                cornerRadius = CornerRadius(10f, 10f)
            )

            // Stitching line
            drawRoundRect(
                color = leatherDark,
                topLeft = Offset(w * 0.18f, h * 0.38f),
                size = Size(w * 0.64f, h * 0.46f),
                cornerRadius = CornerRadius(8f, 8f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
            )

            // Flap and Gold Clasp button
            drawRoundRect(
                color = leatherDark,
                topLeft = Offset(w * 0.54f, h * 0.52f),
                size = Size(w * 0.32f, h * 0.20f),
                cornerRadius = CornerRadius(6f, 6f)
            )
            drawCircle(claspColor, radius = w * 0.045f, center = Offset(w * 0.76f, h * 0.62f))
        }
    }
}

/**
 * 8. جرد المخزن: لوحة فحص وتدقيق المخزون مع علامات صح خضراء
 */
@Composable
fun StocktakeIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Clipboard board
            drawRoundRect(
                color = Color(0xFF8D6E63),
                topLeft = Offset(w * 0.16f, h * 0.12f),
                size = Size(w * 0.68f, h * 0.76f),
                cornerRadius = CornerRadius(8f, 8f)
            )

            // Sheet of paper
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(w * 0.22f, h * 0.20f),
                size = Size(w * 0.56f, h * 0.64f),
                cornerRadius = CornerRadius(4f, 4f)
            )

            // Clip at top
            drawRoundRect(
                color = Color(0xFF455A64),
                topLeft = Offset(w * 0.36f, h * 0.08f),
                size = Size(w * 0.28f, h * 0.12f),
                cornerRadius = CornerRadius(4f, 4f)
            )

            // Lines and Checkmarks
            val checkGreen = Color(0xFF2E7D32)
            for (i in 0..2) {
                val y = h * (0.34f + i * 0.14f)
                drawCircle(checkGreen, radius = w * 0.04f, center = Offset(w * 0.32f, y))
                drawLine(Color(0xFF9E9E9E), Offset(w * 0.42f, y), Offset(w * 0.70f, y), strokeWidth = 5f)
            }
        }
    }
}

/**
 * 9. النواقص: تنبيه أحمر وجرس وإشعار نقص الكميات
 */
@Composable
fun ShortagesIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Yellow/Orange background glow
            drawCircle(Color(0xFFFFEBEE), radius = w * 0.40f, center = Offset(w * 0.5f, h * 0.5f))

            // Warning Triangle (Red/Orange)
            val redColor = Color(0xFFD32F2F)
            val triPath = Path().apply {
                moveTo(w * 0.50f, h * 0.12f)
                lineTo(w * 0.88f, h * 0.78f)
                lineTo(w * 0.12f, h * 0.78f)
                close()
            }
            drawPath(triPath, redColor)

            // Inner exclamation mark
            drawLine(Color.White, Offset(w * 0.50f, h * 0.34f), Offset(w * 0.50f, h * 0.56f), strokeWidth = 8f)
            drawCircle(Color.White, radius = 4f, center = Offset(w * 0.50f, h * 0.68f))
        }
    }
}

/**
 * 10. التقارير: رسم بياني تصاعدي ومؤشرات أداء المخزن
 */
@Composable
fun ReportsIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Chart base card
            drawRoundRect(
                color = Color(0xFFE8F5E9),
                topLeft = Offset(w * 0.12f, h * 0.14f),
                size = Size(w * 0.76f, h * 0.72f),
                cornerRadius = CornerRadius(8f, 8f)
            )

            // Bars
            drawRoundRect(Color(0xFF81C784), Offset(w * 0.22f, h * 0.52f), Size(w * 0.12f, h * 0.26f), CornerRadius(4f, 4f))
            drawRoundRect(Color(0xFF4CAF50), Offset(w * 0.40f, h * 0.38f), Size(w * 0.12f, h * 0.40f), CornerRadius(4f, 4f))
            drawRoundRect(Color(0xFF2E7D32), Offset(w * 0.58f, h * 0.24f), Size(w * 0.12f, h * 0.54f), CornerRadius(4f, 4f))

            // Rising trend line (Orange)
            val trendPath = Path().apply {
                moveTo(w * 0.24f, h * 0.50f)
                lineTo(w * 0.44f, h * 0.36f)
                lineTo(w * 0.64f, h * 0.20f)
                lineTo(w * 0.78f, h * 0.18f)
            }
            drawPath(trendPath, Color(0xFFFF9800), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6f))
        }
    }
}

/**
 * 11. الطابعة الحرارية: طابعة فواتير محمولة مع ورقة إيصال خارجة
 */
@Composable
fun PrinterIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Paper coming out
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(w * 0.26f, h * 0.10f),
                size = Size(w * 0.48f, h * 0.36f),
                cornerRadius = CornerRadius(2f, 2f)
            )
            // Paper text lines
            drawLine(Color(0xFFBDBDBD), Offset(w * 0.32f, h * 0.18f), Offset(w * 0.68f, h * 0.18f), strokeWidth = 4f)
            drawLine(Color(0xFFBDBDBD), Offset(w * 0.32f, h * 0.24f), Offset(w * 0.60f, h * 0.24f), strokeWidth = 4f)
            drawLine(Color(0xFFBDBDBD), Offset(w * 0.32f, h * 0.30f), Offset(w * 0.64f, h * 0.30f), strokeWidth = 4f)

            // Printer Body (Dark Charcoal)
            val printerBody = Color(0xFF37474F)
            drawRoundRect(
                color = printerBody,
                topLeft = Offset(w * 0.14f, h * 0.34f),
                size = Size(w * 0.72f, h * 0.52f),
                cornerRadius = CornerRadius(10f, 10f)
            )

            // Paper exit slot
            drawRoundRect(
                color = Color(0xFF212121),
                topLeft = Offset(w * 0.22f, h * 0.36f),
                size = Size(w * 0.56f, h * 0.08f),
                cornerRadius = CornerRadius(4f, 4f)
            )

            // Power / Feed buttons
            drawCircle(Color(0xFF4CAF50), radius = 6f, center = Offset(w * 0.28f, h * 0.64f)) // Power LED
            drawCircle(Color(0xFF29B6F6), radius = 6f, center = Offset(w * 0.40f, h * 0.64f)) // Bluetooth LED
        }
    }
}

/**
 * 12. أمان ومفتاح بدء التشغيل: درع ذهبي وقفل أمان وترخيص
 */
@Composable
fun SecurityIllustration(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(80.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(76.dp)) {
            val w = size.width
            val h = size.height

            // Gold Shield
            val shieldPath = Path().apply {
                moveTo(w * 0.50f, h * 0.12f)
                lineTo(w * 0.82f, h * 0.24f)
                lineTo(w * 0.78f, h * 0.60f)
                lineTo(w * 0.50f, h * 0.86f)
                lineTo(w * 0.22f, h * 0.60f)
                lineTo(w * 0.18f, h * 0.24f)
                close()
            }
            drawPath(shieldPath, Brush.verticalGradient(listOf(Color(0xFFFFD54F), Color(0xFFFFB300))))

            // Padlock in center
            drawRoundRect(
                color = Color(0xFF37474F),
                topLeft = Offset(w * 0.36f, h * 0.44f),
                size = Size(w * 0.28f, h * 0.26f),
                cornerRadius = CornerRadius(4f, 4f)
            )
            // Shackle
            drawRoundRect(
                color = Color(0xFF455A64),
                topLeft = Offset(w * 0.41f, h * 0.32f),
                size = Size(w * 0.18f, h * 0.20f),
                cornerRadius = CornerRadius(6f, 6f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 5f)
            )
            // Keyhole
            drawCircle(Color(0xFFFFD54F), radius = 4f, center = Offset(w * 0.50f, h * 0.54f))
        }
    }
}
