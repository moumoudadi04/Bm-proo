package com.example.printer

import android.content.Context
import android.print.PrintAttributes
import android.print.PrintManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import com.example.data.model.InvoiceEntity
import com.example.data.model.InvoiceItemEntity
import com.example.data.model.StocktakeItemEntity
import com.example.data.model.StocktakeSessionEntity
import java.io.ByteArrayOutputStream
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class PrinterPaperWidth(val label: String, val charsPerLine: Int) {
    WIDTH_58MM("58mm (32 chars)", 32),
    WIDTH_80MM("80mm (48 chars)", 48)
}

enum class PrinterConnectionType(val labelAr: String, val labelEn: String) {
    BLUETOOTH("بلوتوث (Bluetooth)", "Bluetooth Wireless"),
    WIFI_LAN("واي فاي / شبكة (Wi-Fi LAN)", "Wi-Fi / Ethernet 9100"),
    SYSTEM_PRINT("خدمة الطباعة بالنظام", "Android Print Spooler")
}

data class PrinterConfig(
    val printerName: String = "BM-POS-Thermal",
    val connectionType: PrinterConnectionType = PrinterConnectionType.BLUETOOTH,
    val wifiIpAddress: String = "192.168.1.200",
    val wifiPort: Int = 9100,
    val paperWidth: PrinterPaperWidth = PrinterPaperWidth.WIDTH_58MM,
    val storeName: String = "BM لوجستيك لإدارة المخازن والشاحنات",
    val storeAddress: String = "الرياض - مركز التوزيع الرئيسي",
    val storePhone: String = "+966 50 123 4567",
    val taxNumber: String = "310123456700003",
    val footerMessage: String = "شكراً لتعاملكم مع BM - بضاعة معتمدة دولياً",
    val autoCutPaper: Boolean = true,
    val isConnected: Boolean = true,
    val currencySymbol: String = "ر.س"
)

object ThermalPrinterManager {

    private val dateFormat = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())

    /**
     * Builds plain text thermal ticket for preview and sharing (e.g. WhatsApp)
     */
    fun buildInvoiceTextReceipt(
        invoice: InvoiceEntity,
        items: List<InvoiceItemEntity>,
        config: PrinterConfig
    ): String {
        val width = config.paperWidth.charsPerLine
        val divider = "-".repeat(width)
        val sb = StringBuilder()

        // Header
        sb.append(centerText(config.storeName, width)).append("\n")
        sb.append(centerText(config.storeAddress, width)).append("\n")
        sb.append(centerText("هاتف: ${config.storePhone}", width)).append("\n")
        if (config.taxNumber.isNotEmpty()) {
            sb.append(centerText("الرقم الضريبي: ${config.taxNumber}", width)).append("\n")
        }
        sb.append(divider).append("\n")

        // Invoice Meta
        sb.append("فاتورة رقم: ${invoice.invoiceNumber}\n")
        sb.append("التاريخ: ${dateFormat.format(Date(invoice.timestamp))}\n")
        sb.append("العميل: ${invoice.partyName}\n")
        sb.append("طريقة الدفع: ${invoice.paymentMethod.name}\n")
        sb.append(divider).append("\n")

        // Columns
        if (config.paperWidth == PrinterPaperWidth.WIDTH_58MM) {
            sb.append(formatLine58("الصنف", "الكمية", "المجموع")).append("\n")
            sb.append(divider).append("\n")
            for (item in items) {
                sb.append(item.productName).append("\n")
                val qtyPrice = "${item.quantity} x ${String.format(Locale.US, "%.2f", item.unitPrice)}"
                val totalStr = String.format(Locale.US, "%.2f", item.total)
                sb.append(formatLine58("", qtyPrice, totalStr)).append("\n")
            }
        } else {
            sb.append(formatLine80("الصنف", "الكمية", "السعر", "الإجمالي")).append("\n")
            sb.append(divider).append("\n")
            for (item in items) {
                sb.append(
                    formatLine80(
                        item.productName.take(20),
                        "${item.quantity}",
                        String.format(Locale.US, "%.2f", item.unitPrice),
                        String.format(Locale.US, "%.2f", item.total)
                    )
                ).append("\n")
            }
        }

        sb.append(divider).append("\n")

        // Totals
        sb.append(alignKeyValue("المجموع الفرعي:", String.format(Locale.US, "%.2f", invoice.subtotal), width)).append("\n")
        if (invoice.discount > 0) {
            sb.append(alignKeyValue("الخصم:", "-${String.format(Locale.US, "%.2f", invoice.discount)}", width)).append("\n")
        }
        if (invoice.taxRate > 0) {
            val taxAmount = (invoice.subtotal - invoice.discount) * invoice.taxRate
            sb.append(alignKeyValue("ضريبة القيمة المضافة (15%):", String.format(Locale.US, "%.2f", taxAmount), width)).append("\n")
        }
        sb.append(divider).append("\n")
        sb.append(alignKeyValue("الصافي الإجمالي:", "${String.format(Locale.US, "%.2f", invoice.totalAmount)} ريال", width)).append("\n")
        sb.append(divider).append("\n")

        // Footer & Barcode simulation
        sb.append(centerText(config.footerMessage, width)).append("\n")
        sb.append(centerText("* ${invoice.invoiceNumber} *", width)).append("\n")
        sb.append(centerText("[ QR CODE VERIFIED ]", width)).append("\n")
        sb.append("\n\n")

        return sb.toString()
    }

    /**
     * Builds ESC/POS binary command stream for real Bluetooth/Network thermal printers
     */
    fun buildEscPosBytes(
        invoice: InvoiceEntity,
        items: List<InvoiceItemEntity>,
        config: PrinterConfig
    ): ByteArray {
        val out = ByteArrayOutputStream()
        val charset = Charset.forName("CP864") // Common Arabic ESC/POS encoding

        // 1. Initialize printer: ESC @ (1B 40)
        out.write(byteArrayOf(0x1B, 0x40))

        // 2. Center alignment: ESC a 1 (1B 61 01)
        out.write(byteArrayOf(0x1B, 0x61, 0x01))

        // 3. Bold On: ESC E 1 (1B 45 01)
        out.write(byteArrayOf(0x1B, 0x45, 0x01))

        // Store Name (Double height/width): GS ! 11 (1D 21 11)
        out.write(byteArrayOf(0x1D, 0x21, 0x11))
        out.write("${config.storeName}\n".toByteArray(charset))

        // Normal text size: GS ! 00 (1D 21 00)
        out.write(byteArrayOf(0x1D, 0x21, 0x00))
        out.write(byteArrayOf(0x1B, 0x45, 0x00)) // Bold Off

        out.write("${config.storeAddress}\n".toByteArray(charset))
        out.write("هاتف: ${config.storePhone}\n".toByteArray(charset))
        if (config.taxNumber.isNotEmpty()) {
            out.write("الرقم الضريبي: ${config.taxNumber}\n".toByteArray(charset))
        }

        val textReceipt = buildInvoiceTextReceipt(invoice, items, config)
        out.write(textReceipt.toByteArray(charset))

        // Paper Feed (3 lines)
        out.write(byteArrayOf(0x1B, 0x64, 0x03))

        // Auto Cut: GS V 66 0 (1D 56 42 00)
        if (config.autoCutPaper) {
            out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))
        }

        return out.toByteArray()
    }

    /**
     * Builds HTML representation for printing via Android system PrintManager
     */
    fun buildHtmlReceipt(
        invoice: InvoiceEntity,
        items: List<InvoiceItemEntity>,
        config: PrinterConfig
    ): String {
        val is58mm = config.paperWidth == PrinterPaperWidth.WIDTH_58MM
        val widthPx = if (is58mm) "320px" else "480px"

        val itemsHtml = StringBuilder()
        for (item in items) {
            itemsHtml.append(
                """
                <tr>
                    <td style="text-align: right; padding: 4px 0;">${item.productName}</td>
                    <td style="text-align: center; padding: 4px 0;">${item.quantity}</td>
                    <td style="text-align: center; padding: 4px 0;">${String.format(Locale.US, "%.2f", item.unitPrice)}</td>
                    <td style="text-align: left; padding: 4px 0; font-weight: bold;">${String.format(Locale.US, "%.2f", item.total)}</td>
                </tr>
                """.trimIndent()
            )
        }

        val taxAmount = if (invoice.taxRate > 0) (invoice.subtotal - invoice.discount) * invoice.taxRate else 0.0

        return """
        <!DOCTYPE html>
        <html dir="rtl" lang="ar">
        <head>
            <meta charset="UTF-8">
            <style>
                body {
                    font-family: 'Courier New', Courier, monospace, sans-serif;
                    width: $widthPx;
                    margin: 0 auto;
                    padding: 12px;
                    color: #000;
                    background: #fff;
                    font-size: 13px;
                    line-height: 1.4;
                }
                .text-center { text-align: center; }
                .text-bold { font-weight: bold; }
                .divider { border-top: 1px dashed #000; margin: 8px 0; }
                table { width: 100%; border-collapse: collapse; }
                .flex-row { display: flex; justify-content: space-between; margin: 3px 0; }
                .barcode-box {
                    text-align: center;
                    letter-spacing: 4px;
                    font-weight: bold;
                    margin-top: 10px;
                    font-size: 14px;
                }
                .qr-box {
                    margin: 8px auto;
                    width: 70px;
                    height: 70px;
                    border: 2px solid #000;
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    font-size: 10px;
                }
            </style>
        </head>
        <body>
            <div class="text-center text-bold" style="font-size: 16px;">${config.storeName}</div>
            <div class="text-center">${config.storeAddress}</div>
            <div class="text-center">هاتف: ${config.storePhone}</div>
            ${if (config.taxNumber.isNotEmpty()) "<div class='text-center'>الرقم الضريبي: ${config.taxNumber}</div>" else ""}
            <div class="divider"></div>

            <div class="flex-row"><span>رقم الفاتورة:</span><span class="text-bold">${invoice.invoiceNumber}</span></div>
            <div class="flex-row"><span>التاريخ:</span><span>${dateFormat.format(Date(invoice.timestamp))}</span></div>
            <div class="flex-row"><span>العميل:</span><span>${invoice.partyName}</span></div>
            <div class="flex-row"><span>طريقة السداد:</span><span class="text-bold">${invoice.paymentMethod.name}</span></div>
            <div class="divider"></div>

            <table>
                <thead>
                    <tr style="border-bottom: 1px solid #000;">
                        <th style="text-align: right; padding-bottom: 4px;">الصنف</th>
                        <th style="text-align: center; padding-bottom: 4px;">الكمية</th>
                        <th style="text-align: center; padding-bottom: 4px;">السعر</th>
                        <th style="text-align: left; padding-bottom: 4px;">الإجمالي</th>
                    </tr>
                </thead>
                <tbody>
                    $itemsHtml
                </tbody>
            </table>

            <div class="divider"></div>
            <div class="flex-row"><span>المجموع:</span><span>${String.format(Locale.US, "%.2f", invoice.subtotal)} ريال</span></div>
            ${if (invoice.discount > 0) "<div class='flex-row'><span>الخصم:</span><span>-${String.format(Locale.US, "%.2f", invoice.discount)} ريال</span></div>" else ""}
            ${if (taxAmount > 0) "<div class='flex-row'><span>ضريبة (15%):</span><span>${String.format(Locale.US, "%.2f", taxAmount)} ريال</span></div>" else ""}
            <div class="divider"></div>
            <div class="flex-row text-bold" style="font-size: 15px;"><span>الصافي المطلوب:</span><span>${String.format(Locale.US, "%.2f", invoice.totalAmount)} ريال</span></div>
            <div class="divider"></div>

            <div class="text-center" style="font-size: 11px; margin-top: 6px;">${config.footerMessage}</div>
            <div class="barcode-box">||| | ||||| || ||| |||||</div>
            <div class="text-center" style="font-size: 10px;">* ${invoice.invoiceNumber} *</div>
            <div class="qr-box">QR FATURA</div>
            <div class="text-center" style="font-size: 9px; color: #555;">طبع بواسطة ProSto System</div>
        </body>
        </html>
        """.trimIndent()
    }

    /**
     * Triggers the Android system PrintManager dialog to print to any physical or virtual printer
     */
    fun printViaSystemPrintManager(
        context: Context,
        jobName: String,
        htmlContent: String
    ) {
        val webView = WebView(context)
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false

            override fun onPageFinished(view: WebView, url: String) {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as? PrintManager
                val printAdapter = webView.createPrintDocumentAdapter(jobName)
                val printAttributes = PrintAttributes.Builder()
                    .setMediaSize(PrintAttributes.MediaSize.ISO_A6)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .build()

                printManager?.print(jobName, printAdapter, printAttributes)
            }
        }
        webView.loadDataWithBaseURL(null, htmlContent, "text/HTML", "UTF-8", null)
    }

    /**
     * Generates a test print report
     */
    fun buildTestReceipt(config: PrinterConfig): String {
        val width = config.paperWidth.charsPerLine
        val divider = "=".repeat(width)
        val sb = StringBuilder()
        sb.append(centerText("=== اختبار الطابعة الحرارية ===", width)).append("\n")
        sb.append(centerText(config.storeName, width)).append("\n")
        sb.append(divider).append("\n")
        sb.append("اسم الطابعة: ${config.printerName}\n")
        sb.append("عرض الورق: ${config.paperWidth.label}\n")
        sb.append("الحالة: متصلة بنجاح (جاهزة للطباعة)\n")
        sb.append("تاريخ الفحص: ${dateFormat.format(Date())}\n")
        sb.append("-".repeat(width)).append("\n")
        sb.append("تدرج الحروف والأرقام:\n")
        sb.append("1234567890 ABCDEFGHIJKLMNOP\n")
        sb.append("أ ب ت ث ج ح خ د ذ ر ز س ش ص ض\n")
        sb.append("-".repeat(width)).append("\n")
        sb.append(centerText("||||||||||||||||||||||", width)).append("\n")
        sb.append(centerText("* TEST-OK-PROSTO *", width)).append("\n")
        sb.append(centerText("نجح اختبار الطابعة الحرارية 100%", width)).append("\n")
        sb.append(divider).append("\n\n")
        return sb.toString()
    }

    /**
     * Stocktake Audit Receipt generator
     */
    fun buildStocktakeReceipt(
        session: StocktakeSessionEntity,
        items: List<StocktakeItemEntity>,
        config: PrinterConfig
    ): String {
        val width = config.paperWidth.charsPerLine
        val divider = "-".repeat(width)
        val sb = StringBuilder()

        sb.append(centerText("تقرير محضر الجرد المخزني", width)).append("\n")
        sb.append(centerText(config.storeName, width)).append("\n")
        sb.append(divider).append("\n")
        sb.append("الجلسة: ${session.title}\n")
        sb.append("التاريخ: ${dateFormat.format(Date(session.startedAt))}\n")
        sb.append("الحالة: ${session.status.name}\n")
        sb.append(divider).append("\n")
        sb.append(formatLine58("الصنف", "المتوقع/الفعلي", "الفارق")).append("\n")
        sb.append(divider).append("\n")

        for (item in items) {
            sb.append(item.productName).append("\n")
            val counts = "${item.expectedStock} -> ${item.actualCount}"
            val diffStr = if (item.variance > 0) "+${item.variance}" else "${item.variance}"
            sb.append(formatLine58("", counts, diffStr)).append("\n")
        }

        sb.append(divider).append("\n")
        sb.append("الأصناف المفحوصة: ${session.totalItemsChecked}\n")
        sb.append("فروقات الجرد: ${session.discrepanciesCount}\n")
        sb.append("صافي قيمة الفروقات: ${String.format(Locale.US, "%.2f", session.totalVarianceValue)} ريال\n")
        sb.append(divider).append("\n")
        sb.append(centerText("توقيع مسؤول المخزن: _____________", width)).append("\n")
        sb.append(centerText("توقيع المحاسب: _____________", width)).append("\n\n")
        return sb.toString()
    }

    private fun centerText(text: String, width: Int): String {
        if (text.length >= width) return text.take(width)
        val padding = (width - text.length) / 2
        val leftPad = " ".repeat(padding)
        val rightPad = " ".repeat(width - text.length - padding)
        return leftPad + text + rightPad
    }

    private fun alignKeyValue(key: String, value: String, width: Int): String {
        val spaces = width - key.length - value.length
        return if (spaces > 0) key + " ".repeat(spaces) + value else "$key $value"
    }

    private fun formatLine58(col1: String, col2: String, col3: String): String {
        // Total 32 chars: 14 + 10 + 8
        val c1 = col1.take(14).padEnd(14)
        val c2 = col2.take(10).padStart(10)
        val c3 = col3.take(8).padStart(8)
        return "$c1$c2$c3"
    }

    private fun formatLine80(col1: String, col2: String, col3: String, col4: String): String {
        // Total 48 chars: 20 + 8 + 10 + 10
        val c1 = col1.take(20).padEnd(20)
        val c2 = col2.take(8).padStart(8)
        val c3 = col3.take(10).padStart(10)
        val c4 = col4.take(10).padStart(10)
        return "$c1$c2$c3$c4"
    }
}
