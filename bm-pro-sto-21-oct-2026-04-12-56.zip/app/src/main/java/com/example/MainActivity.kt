package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PointOfSale
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QueryStats
import androidx.compose.material.icons.outlined.Assessment
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.PointOfSale
import androidx.compose.material.icons.outlined.QueryStats
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainViewModel
import com.example.ui.Screen
import com.example.ui.components.ProStoTopBar
import com.example.ui.components.SecuritySettingsDialog
import com.example.ui.components.ThermalReceiptDialog
import com.example.ui.screens.ActivationScreen
import com.example.ui.screens.CloudSyncScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.NewInvoiceScreen
import com.example.ui.screens.PrinterSettingsScreen
import com.example.ui.screens.DebtScreen
import com.example.ui.screens.ProductsScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.ShortagesScreen
import com.example.ui.screens.StocktakeScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ProTeal
import com.example.util.AppLanguage
import com.example.util.LocalAppLanguage
import com.example.util.Strings

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                ProStoApp()
            }
        }
    }
}

@Composable
fun ProStoApp(viewModel: MainViewModel = viewModel()) {
    val isActivated by viewModel.isActivated.collectAsState()
    val showSecurityDialog by viewModel.showSecuritySettingsDialog.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentLanguage by viewModel.currentLanguage.collectAsState()
    val shiftState by viewModel.shiftState.collectAsState()
    val lowStockList by viewModel.lowStockProducts.collectAsState()
    val overdueDebts by viewModel.overdueDebts.collectAsState()
    val receiptDialogState by viewModel.receiptDialogState.collectAsState()
    val printerConfig by viewModel.printerConfig.collectAsState()

    // Dynamic RTL / LTR layout direction depending on chosen language
    CompositionLocalProvider(
        LocalLayoutDirection provides currentLanguage.layoutDirection,
        LocalAppLanguage provides currentLanguage
    ) {
        if (!isActivated) {
            // First install / new phone activation screen
            ActivationScreen(
                securityManager = viewModel.securityManager,
                currentLanguage = currentLanguage,
                onActivated = {
                    // State flow in SecurityManager automatically triggers recomposition
                }
            )
        } else {
            // Handle back button to return to Dashboard if on a sub-screen
            BackHandler(enabled = currentScreen != Screen.DASHBOARD) {
                viewModel.navigateTo(Screen.DASHBOARD)
            }

            Scaffold(
                topBar = {
                    ProStoTopBar(
                        shiftState = shiftState,
                        currentLanguage = currentLanguage,
                        lowStockCount = lowStockList.size,
                        onToggleStartupKey = { viewModel.toggleStartupKey() },
                        onToggleLanguage = { viewModel.toggleLanguage() },
                        onOpenPrinter = { viewModel.navigateTo(Screen.PRINTER_SETTINGS) },
                        onOpenCloud = { viewModel.navigateTo(Screen.CLOUD_SYNC) },
                        onOpenSecurity = { viewModel.openSecuritySettings() }
                    )
                },
                bottomBar = {
                    ProStoBottomBar(
                        currentScreen = currentScreen,
                        lowStockCount = lowStockList.size,
                        overdueDebtsCount = overdueDebts.size,
                        currentLanguage = currentLanguage,
                        onSelect = { viewModel.navigateTo(it) }
                    )
                },
                modifier = Modifier.fillMaxSize()
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "screen_transition"
                    ) { screen ->
                        when (screen) {
                            Screen.DASHBOARD -> DashboardScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                            Screen.PRODUCTS -> ProductsScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                            Screen.NEW_INVOICE -> NewInvoiceScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                            Screen.STOCKTAKE -> StocktakeScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                            Screen.SHORTAGES -> ShortagesScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                            Screen.DEBTS -> DebtScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                            Screen.REPORTS -> ReportsScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                            Screen.PRINTER_SETTINGS -> PrinterSettingsScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                            Screen.CLOUD_SYNC -> CloudSyncScreen(viewModel = viewModel, currentLanguage = currentLanguage)
                        }
                    }
                }

                // Global Thermal Receipt Dialog
                ThermalReceiptDialog(
                    state = receiptDialogState,
                    printerConfig = printerConfig,
                    currentLanguage = currentLanguage,
                    onDismiss = { viewModel.closeReceiptDialog() }
                )

                // Master Password & Security Settings Dialog
                if (showSecurityDialog) {
                    SecuritySettingsDialog(
                        securityManager = viewModel.securityManager,
                        currentLanguage = currentLanguage,
                        onDismiss = { viewModel.closeSecuritySettings() }
                    )
                }
            }
        }
    }
}

@Composable
fun ProStoBottomBar(
    currentScreen: Screen,
    lowStockCount: Int,
    overdueDebtsCount: Int,
    currentLanguage: AppLanguage,
    onSelect: (Screen) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 6.dp
    ) {
        // 1. Dashboard
        NavigationBarItem(
            selected = currentScreen == Screen.DASHBOARD,
            onClick = { onSelect(Screen.DASHBOARD) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.DASHBOARD) Icons.Filled.Dashboard else Icons.Outlined.Dashboard,
                    contentDescription = Strings.get("dashboard", currentLanguage)
                )
            },
            label = { Text(text = Strings.get("dashboard", currentLanguage), fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = ProTeal.copy(alpha = 0.2f),
                selectedIconColor = ProTeal,
                selectedTextColor = ProTeal
            ),
            modifier = Modifier.testTag("nav_dashboard")
        )

        // 2. Inventory Products
        NavigationBarItem(
            selected = currentScreen == Screen.PRODUCTS,
            onClick = { onSelect(Screen.PRODUCTS) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.PRODUCTS) Icons.Filled.Inventory2 else Icons.Outlined.Inventory2,
                    contentDescription = Strings.get("inventory", currentLanguage)
                )
            },
            label = { Text(text = Strings.get("inventory", currentLanguage), fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = ProTeal.copy(alpha = 0.2f),
                selectedIconColor = ProTeal,
                selectedTextColor = ProTeal
            ),
            modifier = Modifier.testTag("nav_products")
        )

        // 3. New Invoice / POS
        NavigationBarItem(
            selected = currentScreen == Screen.NEW_INVOICE,
            onClick = { onSelect(Screen.NEW_INVOICE) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.NEW_INVOICE) Icons.Filled.PointOfSale else Icons.Outlined.PointOfSale,
                    contentDescription = Strings.get("new_invoice", currentLanguage)
                )
            },
            label = { Text(text = Strings.get("new_invoice", currentLanguage), fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = ProTeal.copy(alpha = 0.2f),
                selectedIconColor = ProTeal,
                selectedTextColor = ProTeal
            ),
            modifier = Modifier.testTag("nav_new_invoice")
        )

        // 4. Customer Debts & Overdue Alerts (الديون)
        NavigationBarItem(
            selected = currentScreen == Screen.DEBTS,
            onClick = { onSelect(Screen.DEBTS) },
            icon = {
                BadgedBox(
                    badge = {
                        if (overdueDebtsCount > 0) {
                            Badge { Text("$overdueDebtsCount") }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Filled.Assessment,
                        contentDescription = "الديون"
                    )
                }
            },
            label = { Text(text = "الديون والتحصيل", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = com.example.ui.theme.ProAmber.copy(alpha = 0.2f),
                selectedIconColor = com.example.ui.theme.ProAmber,
                selectedTextColor = com.example.ui.theme.ProAmber
            ),
            modifier = Modifier.testTag("nav_debts")
        )

        // 5. Shortages & Alerts (النواقص)
        NavigationBarItem(
            selected = currentScreen == Screen.SHORTAGES,
            onClick = { onSelect(Screen.SHORTAGES) },
            icon = {
                BadgedBox(
                    badge = {
                        if (lowStockCount > 0) {
                            Badge { Text("$lowStockCount") }
                        }
                    }
                ) {
                    Icon(
                        imageVector = if (currentScreen == Screen.SHORTAGES) Icons.Filled.NotificationsActive else Icons.Outlined.NotificationsActive,
                        contentDescription = Strings.get("shortages", currentLanguage)
                    )
                }
            },
            label = { Text(text = Strings.get("shortages", currentLanguage), fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = ProTeal.copy(alpha = 0.2f),
                selectedIconColor = ProTeal,
                selectedTextColor = ProTeal
            ),
            modifier = Modifier.testTag("nav_shortages")
        )

        // 6. Reports (التقارير)
        NavigationBarItem(
            selected = currentScreen == Screen.REPORTS,
            onClick = { onSelect(Screen.REPORTS) },
            icon = {
                Icon(
                    imageVector = if (currentScreen == Screen.REPORTS) Icons.Filled.QueryStats else Icons.Outlined.QueryStats,
                    contentDescription = Strings.get("reports", currentLanguage)
                )
            },
            label = { Text(text = Strings.get("reports", currentLanguage), fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = ProTeal.copy(alpha = 0.2f),
                selectedIconColor = ProTeal,
                selectedTextColor = ProTeal
            ),
            modifier = Modifier.testTag("nav_reports")
        )
    }
}
